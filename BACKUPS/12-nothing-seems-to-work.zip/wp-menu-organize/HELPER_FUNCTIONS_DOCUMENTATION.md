# Helper Functions Documentation

## Overview
This document describes the new helper functions added to reduce code duplication while maintaining backward compatibility.

## New Helper Functions

### 1. `wmo_validate_ajax_request_enhanced()`

Enhanced AJAX validation with custom message support.

**Usage:**
```php
// Basic usage (replaces old manual checks)
wmo_validate_ajax_request_enhanced();

// With custom error message
wmo_validate_ajax_request_enhanced(array(
    'error_message' => 'You need admin privileges to modify templates'
));

// With custom capability check
wmo_validate_ajax_request_enhanced(array(
    'capability' => 'edit_posts',
    'error_message' => 'You need editor privileges'
));
```

**Parameters:**
- `capability` - WordPress capability to check (default: 'manage_options')
- `error_message` - Custom error message for permission failure
- `nonce_action` - Nonce action to verify (default: 'wmo_ajax_nonce')
- `nonce_field` - Nonce field name (default: 'nonce')
- `die_on_fail` - Whether to die on failure (default: true)

**Benefits:**
- Maintains specific error messages
- Backward compatible
- Reduces duplicate security checks

### 2. `wmo_validate_color()`

Centralized color validation and sanitization.

**Usage:**
```php
// Basic color validation
$color = wmo_validate_color($_POST['color']);

// Require non-empty color
$color = wmo_validate_color($_POST['color'], false);

// Allow transparent value
$color = wmo_validate_color($_POST['color'], true, true);
```

**Parameters:**
- `$color` - The color value to validate
- `$allow_empty` - Whether to allow empty values (default: true)
- `$allow_transparency` - Whether to allow 'transparent' value (default: false)

**Returns:** Sanitized color string or false if invalid

### 3. `wmo_sanitize_menu_slug()`

Standardized slug sanitization for menu items.

**Usage:**
```php
$slug = wmo_sanitize_menu_slug($_POST['menu_slug']);
```

**Benefits:**
- Consistent sanitization across all handlers
- Additional XSS protection
- Single point for slug validation rules

### 4. `wmo_is_parent_menu()`

Check if a slug represents a parent menu item.

**Usage:**
```php
if (wmo_is_parent_menu($slug)) {
    // Handle parent menu logic
} else {
    // Handle submenu logic
}
```

**Benefits:**
- Centralized parent/submenu detection logic
- Easy to update if WordPress changes menu structure
- Consistent behavior across the plugin

### 5. `wmo_ajax_response()`

Standardized AJAX response helper.

**Usage:**
```php
// Success response with data
wmo_ajax_response(true, $data, 'Operation completed successfully');

// Error response
wmo_ajax_response(false, null, 'Operation failed');

// Success with data only (no message)
wmo_ajax_response(true, array('id' => $id, 'color' => $color));
```

**Benefits:**
- Consistent response format
- Automatic exit after response
- Cleaner code

## Migration Guide

### Old Code:
```php
function my_ajax_handler() {
    if (!wp_verify_nonce($_POST['nonce'], 'wmo_ajax_nonce')) {
        wp_send_json_error('Invalid nonce');
    }
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Insufficient permissions');
    }
    
    $slug = sanitize_text_field($_POST['slug']);
    $color = sanitize_hex_color($_POST['color']);
    
    // ... logic ...
    
    wp_send_json_success(array(
        'message' => 'Saved successfully',
        'data' => $result
    ));
}
```

### New Code (Using Helpers):
```php
function my_ajax_handler() {
    wmo_validate_ajax_request_enhanced(array(
        'error_message' => 'Custom permission message'
    ));
    
    $slug = wmo_sanitize_menu_slug($_POST['slug']);
    $color = wmo_validate_color($_POST['color']);
    
    // ... logic ...
    
    wmo_ajax_response(true, $result, 'Saved successfully');
}
```

## Backward Compatibility

### IMPORTANT: Existing Functions Remain Unchanged
- All existing AJAX handlers continue to work
- No breaking changes to public APIs
- Helper functions are OPTIONAL - use them for new code or when refactoring

### Gradual Migration Strategy
1. **New features** - Use helper functions
2. **Bug fixes** - Update to helpers if touching the code
3. **Existing stable code** - Leave as-is unless necessary

## Example Implementation

The `wmo_save_background_color()` function has been updated as an example:

```php
function wmo_save_background_color() {
    // Using new enhanced validation
    wmo_validate_ajax_request_enhanced(array(
        'error_message' => 'You need admin privileges to modify background colors'
    ));
    
    // Using sanitization helper
    $item_id = wmo_sanitize_menu_slug($_POST['id']);
    
    // Using color validation helper
    $color = wmo_validate_color($_POST['color'], true, false);
    
    // Rest of function remains the same...
}
```

## Benefits Summary

1. **Reduced Duplication** - Common logic in one place
2. **Flexibility** - Custom messages and parameters
3. **Backward Compatible** - No breaking changes
4. **Maintainable** - Single point for updates
5. **Safe** - Gradual migration path
6. **Clear** - Self-documenting function names

## Testing Checklist

Before using helpers in production:
- [ ] Test with valid permissions
- [ ] Test with invalid permissions
- [ ] Test with valid/invalid nonces
- [ ] Test color validation edge cases
- [ ] Test slug sanitization with special characters
- [ ] Verify backward compatibility
- [ ] Check JavaScript still receives expected responses

## Future Improvements

Potential future enhancements (not implemented yet):
- Add logging capability to helpers
- Add rate limiting support
- Add caching for repeated validations
- Create JavaScript equivalents for client-side validation