# Fix for Parent Menu Color Inheriting to Submenu Items

## Problem
When setting a background color for a parent menu item (e.g., "Menu Organize"), the color was being applied to ALL submenu items underneath it, overriding the default transparent background and preventing individual submenu colors from displaying properly.

## Root Cause
The CSS selectors in `wmo_apply_menu_background_colors()` were using descendant selectors instead of direct child selectors:

**Problematic selectors:**
```css
body #adminmenu li#menu-{$slug} a,  /* Matches ALL <a> tags within the menu item */
body #adminmenu li#toplevel_page_{$slug} a,  /* Including submenu items! */
```

**Correct selectors:**
```css
body #adminmenu li#menu-{$slug} > a,  /* Only matches direct child <a> tag */
body #adminmenu li#toplevel_page_{$slug} > a,  /* Parent menu item only */
```

The lack of the `>` (direct child) selector caused the CSS to apply to all anchor tags within the parent menu structure, including submenu items.

## Solution Implemented

### 1. Fixed CSS Selectors in PHP (`ajax-handlers.php`)
- Changed all parent menu background color selectors to use `>` for direct child targeting
- Added explicit rules to reset submenu backgrounds to transparent
- Ensures submenu items don't inherit parent colors unless explicitly set

### 2. Updated JavaScript Applier (`background-color-applier.js`)
- Added logic to reset submenu backgrounds when applying parent colors
- Only resets if no specific color is already set for the submenu
- Prevents visual inheritance while preserving user-set submenu colors

## Files Modified

1. **`includes/ajax-handlers.php`** (lines 418-438)
   - Fixed "Alternative selectors" to use `>` selector
   - Added submenu reset rules

2. **`assets/src/js/background-color-applier.js`** (lines 53-70)
   - Added submenu background reset logic
   - Conditional reset to preserve existing colors

## Testing
1. Set a background color for a parent menu item (e.g., Menu Organize → Green)
2. Verify submenu items remain with default/transparent background
3. Set a different color for a submenu item (e.g., Settings → Red)
4. Verify the submenu color is preserved and not overridden by parent
5. Refresh the page and confirm both colors persist correctly

## Before & After

**Before:** 
- Parent: Green background ✓
- All submenus: Green background (inherited) ✗

**After:**
- Parent: Green background ✓
- Submenus: Transparent/default ✓
- Submenu with custom color: Custom color preserved ✓