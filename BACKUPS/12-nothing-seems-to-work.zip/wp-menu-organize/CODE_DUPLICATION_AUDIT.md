# Code Duplication Audit Report

## Summary
Audit performed to identify code duplications and opportunities for refactoring in the WP Menu Organize plugin.

## 1. CRITICAL DUPLICATIONS FOUND

### 1.1 Duplicate Hook Registration
**File:** `includes/ajax-handlers.php`
**Lines:** 1459-1460
```php
add_action('admin_head', 'wmo_apply_theme_preference');
add_action('admin_head', 'wmo_apply_theme_preference');  // DUPLICATE!
```
**Impact:** Function runs twice on every admin page load
**Fix:** Remove line 1460

## 2. REPETITIVE CODE PATTERNS

### 2.1 Permission Checks
**File:** `includes/ajax-handlers.php`
**Occurrences:** 8 times
```php
if (!current_user_can('manage_options')) {
    wp_send_json_error('Insufficient permissions');
}
```
**Lines:** 297, 931, 990, 1066, 1184, 1235, 1285, 1316
**Recommendation:** Create a helper function `wmo_verify_admin_permission()`

### 2.2 Nonce Verification
**File:** `includes/ajax-handlers.php`
**Occurrences:** 7 times
```php
if (!check_ajax_referer('wmo_ajax_nonce', 'nonce', false)) {
    wp_die('Security check failed');
}
```
**Lines:** 936, 995, 1071, 1188, 1239, 1289, 1321
**Recommendation:** Already have `wmo_validate_ajax_request()` helper - use it consistently

### 2.3 Mixed Security Validation Approaches
Some functions use:
- `wmo_validate_ajax_request()` (newer approach)
- Manual permission + nonce checks (older approach)
- `wp_verify_nonce()` instead of `check_ajax_referer()`

**Recommendation:** Standardize on `wmo_validate_ajax_request()` for all AJAX handlers

## 3. SIMILAR FUNCTIONALITY

### 3.1 Color Saving Functions
Multiple similar functions handling color saving:
- `wmo_save_color()` - For menu item colors
- `wmo_save_background_color()` - For background colors
- `wmo_save_menu_colors()` - For batch color updates

**Recommendation:** Consider consolidating into a single flexible color handler

### 3.2 Import/Export Functions
- `wmo_export_settings_ajax()`
- `wmo_export_configuration()`
- `wmo_import_settings_ajax()`
- `wmo_import_configuration()`

These have overlapping functionality that could be consolidated.

## 4. CSS/STYLE DUPLICATIONS

### 4.1 Background Color Reset
The pattern `background-color: transparent !important` appears in:
- `wp-menu-organize.php`
- `includes/ajax-handlers.php`
- `assets/src/js/background-color-applier.js`

This logic is duplicated across PHP and JavaScript.

## 5. NO ISSUES FOUND

### 5.1 Function Names
✅ No duplicate function names found across PHP files

### 5.2 AJAX Handlers
✅ All AJAX action handlers are unique

### 5.3 JavaScript Functions
✅ No duplicate custom function names (excluding minified libraries)

## 6. RECOMMENDATIONS

### Priority 1 (Critical):
1. **Remove duplicate hook:** Delete line 1460 in `ajax-handlers.php`

### Priority 2 (High):
1. **Standardize security checks:** Use `wmo_validate_ajax_request()` consistently
2. **Create permission helper:** Add `wmo_verify_admin_permission()` function

### Priority 3 (Medium):
1. **Consolidate color handlers:** Merge similar color-saving functions
2. **Unify import/export:** Create single import/export handler with options

### Code to Add:
```php
// Add to helper-functions.php
function wmo_verify_admin_permission() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Insufficient permissions');
        exit;
    }
}

// Update all AJAX handlers to use:
function wmo_some_ajax_handler() {
    wmo_validate_ajax_request(); // This already includes permission + nonce check
    // ... rest of function
}
```

## 7. FILES TO REFACTOR

1. **includes/ajax-handlers.php** - Main target for cleanup
2. **includes/helper-functions.php** - Add new helper functions
3. **assets/src/js/background-color-applier.js** - Sync with PHP logic

## ESTIMATED IMPACT
- **Code reduction:** ~15-20% in ajax-handlers.php
- **Performance:** Minor improvement from removing duplicate hook
- **Maintainability:** Significant improvement
- **Bug risk:** Reduced through standardization