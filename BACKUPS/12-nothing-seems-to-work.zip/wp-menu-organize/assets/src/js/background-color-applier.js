(function($) {
    'use strict';

    // Function to apply background colors to menu items
    function applyBackgroundColors(backgroundColors) {
        if (!backgroundColors || typeof backgroundColors !== 'object') {
            return;
        }

        var parentColors = {};
        var submenuColors = {};
        
        // First, separate parent and submenu colors
        for (var slug in backgroundColors) {
            if (backgroundColors.hasOwnProperty(slug)) {
                var color = backgroundColors[slug];
                if (color) {
                    // Check if this is likely a parent menu item
                    var isParent = slug.indexOf('-') === -1 || 
                                  ['dashboard', 'posts', 'media', 'pages', 'comments', 
                                   'appearance', 'plugins', 'users', 'tools', 'settings'].indexOf(slug) !== -1;
                    
                    if (isParent) {
                        parentColors[slug] = color;
                    } else {
                        submenuColors[slug] = color;
                    }
                }
            }
        }
        
        // Apply parent colors first (with resets)
        for (var parentSlug in parentColors) {
            if (parentColors.hasOwnProperty(parentSlug)) {
                applyBackgroundColorToParentMenu(parentSlug, parentColors[parentSlug]);
            }
        }
        
        // Then apply submenu colors (will override resets)
        for (var submenuSlug in submenuColors) {
            if (submenuColors.hasOwnProperty(submenuSlug)) {
                applyBackgroundColorToSubmenuByText(submenuSlug, submenuColors[submenuSlug]);
            }
        }
    }

    // Apply background color to a specific menu item
    function applyBackgroundColorToMenu(slug, color) {
        // Check if this is likely a parent menu item
        var isParent = slug.indexOf('-') === -1 || 
                      ['dashboard', 'posts', 'media', 'pages', 'comments', 
                       'appearance', 'plugins', 'users', 'tools', 'settings'].indexOf(slug) !== -1;

        if (isParent) {
            // Apply to parent menu items
            applyBackgroundColorToParentMenu(slug, color);
        } else {
            // Apply to submenu items
            applyBackgroundColorToSubmenuByText(slug, color);
        }
    }

    // Apply background color to parent menu items
    function applyBackgroundColorToParentMenu(slug, color) {
        var selectors = [
            '#menu-' + slug + ' > a',
            '#toplevel_page_' + slug + ' > a',
            'li[id="menu-' + slug + '"] > a',
            'li[id="toplevel_page_' + slug + '"] > a'
        ];

        selectors.forEach(function(selector) {
            var elements = document.querySelectorAll(selector);
            elements.forEach(function(element) {
                element.style.setProperty('background-color', color, 'important');
            });
        });
        
        // Reset ALL submenu items to transparent to prevent inheritance
        // This will be overridden later by specific submenu colors in the second pass
        var submenuSelectors = [
            '#menu-' + slug + ' .wp-submenu li a',
            '#toplevel_page_' + slug + ' .wp-submenu li a',
            'li[id="menu-' + slug + '"] .wp-submenu li a',
            'li[id="toplevel_page_' + slug + '"] .wp-submenu li a'
        ];
        
        submenuSelectors.forEach(function(selector) {
            var elements = document.querySelectorAll(selector);
            elements.forEach(function(element) {
                // Force reset to transparent - submenu colors will override this later
                element.style.setProperty('background-color', 'transparent', 'important');
            });
        });
    }

    // Apply background color to submenu items by text matching
    function applyBackgroundColorToSubmenuByText(slug, color) {
        // Find submenu items by text content
        var submenuLinks = document.querySelectorAll('#adminmenu .wp-submenu li a');
        
        submenuLinks.forEach(function(link) {
            var linkText = link.textContent.trim();
            
            // Create variations of the slug for matching
            var slugVariations = [
                slug.toLowerCase(),
                slug.replace(/-/g, ' ').toLowerCase(),
                slug.replace(/-/g, '').toLowerCase(),
                slug.replace(/-/g, ' ').replace(/\b\w/g, function(l) { return l.toUpperCase(); }).toLowerCase()
            ];
            
            // Add common submenu patterns
            if (slug === 'home') {
                slugVariations.push('dashboard', 'main', 'overview');
            }
            if (slug === 'dashboard') {
                slugVariations.push('home', 'main', 'overview');
            }
            
            var linkTextLower = linkText.toLowerCase();
            var isMatch = slugVariations.some(function(variation) {
                return linkTextLower === variation || 
                       linkTextLower.indexOf(variation) !== -1 ||
                       variation.indexOf(linkTextLower) !== -1;
            });
            
            if (isMatch) {
                link.style.setProperty('background-color', color, 'important');
            }
        });

        // Also try URL-based matching for submenu items
        var urlMappings = {
            'home': 'index.php',
            'updates': 'update-core.php',
            'all-posts': 'edit.php',
            'add-post': 'post-new.php',
            'categories': 'edit-tags.php?taxonomy=category',
            'tags': 'edit-tags.php?taxonomy=post_tag',
            'library': 'upload.php',
            'add-new': 'media-new.php',
            'all-pages': 'edit.php?post_type=page',
            'add-page': 'post-new.php?post_type=page',
            'themes': 'themes.php',
            'customize': 'customize.php',
            'widgets': 'widgets.php',
            'menus': 'nav-menus.php',
            'installed-plugins': 'plugins.php',
            'add-plugin': 'plugin-install.php',
            'all-users': 'users.php',
            'add-user': 'user-new.php',
            'profile': 'profile.php',
            'general': 'options-general.php',
            'writing': 'options-writing.php',
            'reading': 'options-reading.php',
            'discussion': 'options-discussion.php',
            'media-settings': 'options-media.php',
            'permalinks': 'options-permalink.php',
            'privacy': 'options-privacy.php'
        };

        if (urlMappings[slug]) {
            var targetUrl = urlMappings[slug];
            var urlSelectors = [
                'a[href="' + targetUrl + '"]',
                'a[href*="' + targetUrl + '"]'
            ];
            
            urlSelectors.forEach(function(selector) {
                var elements = document.querySelectorAll('#adminmenu .wp-submenu li ' + selector);
                elements.forEach(function(element) {
                    element.style.setProperty('background-color', color, 'important');
                });
            });
        }
    }

    // Wait for DOM to be ready
    $(document).ready(function() {
        // Apply background colors if they exist
        if (typeof wmo_background_colors !== 'undefined' && wmo_background_colors) {
            applyBackgroundColors(wmo_background_colors);
        }
    });

})(jQuery);