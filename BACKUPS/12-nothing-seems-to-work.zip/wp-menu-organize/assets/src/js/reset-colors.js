(function($) {
    'use strict';

    $(document).ready(function() {
        // Handle Reset All Colors button click
        $('#wmo-reset-all-colors').on('click', function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var $status = $('#wmo-reset-status');
            
            // Confirm action
            if (!confirm('Are you sure you want to reset ALL background colors to default? This action cannot be undone.')) {
                return;
            }
            
            // Disable button and show loading
            $button.prop('disabled', true);
            $button.find('.dashicons').removeClass('dashicons-image-rotate').addClass('dashicons-update').addClass('spin');
            $status.html('<span style="color: #0073aa;">Resetting colors...</span>').show();
            
            // Make AJAX request
            $.ajax({
                url: wmo_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'wmo_reset_all_background_colors',
                    nonce: wmo_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Show success message
                        $status.html('<span style="color: #46b450;">✓ ' + (response.data.message || 'Colors reset successfully') + '</span>').show();
                        
                        // Clear all color inputs
                        $('.wmo-background-color-field').each(function() {
                            var $input = $(this);
                            
                            // Clear the value
                            $input.val('').trigger('change');
                            
                            // Clear any inline styles on the input
                            $input.css('background-color', '');
                            
                            // If using WordPress color picker, clear it
                            if ($input.data('wpWpColorPicker')) {
                                $input.wpColorPicker('color', '');
                            }
                            
                            // Remove background colors from actual menu items
                            var menuSlug = $input.data('menu-slug');
                            if (menuSlug) {
                                // Remove from parent menu items
                                $('#adminmenu #menu-' + menuSlug + ' > a').css('background-color', '');
                                $('#adminmenu #toplevel_page_' + menuSlug + ' > a').css('background-color', '');
                                
                                // Remove from submenu items
                                $('#adminmenu .wp-submenu li a').each(function() {
                                    $(this).css('background-color', '');
                                });
                            }
                        });
                        
                        // Reload page after a short delay to ensure clean state
                        setTimeout(function() {
                            location.reload();
                        }, 1500);
                        
                    } else {
                        // Show error message
                        $status.html('<span style="color: #dc3232;">✗ ' + (response.data || 'Failed to reset colors') + '</span>').show();
                        
                        // Re-enable button
                        $button.prop('disabled', false);
                        $button.find('.dashicons').removeClass('dashicons-update spin').addClass('dashicons-image-rotate');
                    }
                },
                error: function(xhr, status, error) {
                    // Show error message
                    $status.html('<span style="color: #dc3232;">✗ Network error: ' + error + '</span>').show();
                    
                    // Re-enable button
                    $button.prop('disabled', false);
                    $button.find('.dashicons').removeClass('dashicons-update spin').addClass('dashicons-image-rotate');
                }
            });
        });
    });
    
})(jQuery);

// Add spinning animation CSS if not already present
jQuery(document).ready(function($) {
    if (!$('#wmo-reset-colors-css').length) {
        $('head').append(`
            <style id="wmo-reset-colors-css">
                .dashicons.spin {
                    animation: spin 1s linear infinite;
                }
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
                #wmo-reset-all-colors:disabled {
                    opacity: 0.6;
                    cursor: not-allowed;
                }
            </style>
        `);
    }
});