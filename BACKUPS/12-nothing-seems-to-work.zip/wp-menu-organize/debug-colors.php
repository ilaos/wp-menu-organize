<?php
// Debug script to check what colors are actually saved
require_once('../../../wp-load.php');

if (!current_user_can('manage_options')) {
    die('Access denied');
}

$background_colors = get_option('wmo_menu_background_colors', array());

echo "<h2>Stored Background Colors:</h2>";
echo "<pre>";
print_r($background_colors);
echo "</pre>";

echo "<h2>Analysis:</h2>";
foreach ($background_colors as $slug => $color) {
    $is_parent = !strpos($slug, '-') || 
                in_array($slug, array('dashboard', 'posts', 'media', 'pages', 'comments', 
                                     'appearance', 'plugins', 'users', 'tools', 'settings'));
    
    echo "<p><strong>{$slug}</strong>: {$color} - " . ($is_parent ? "PARENT" : "SUBMENU") . "</p>";
}
?>