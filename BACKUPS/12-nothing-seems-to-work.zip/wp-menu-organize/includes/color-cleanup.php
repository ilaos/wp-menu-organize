<?php
/**
 * Clean up submenu colors that match their parent colors
 * This removes accidental inheritance that was saved to the database
 */

function wmo_cleanup_inherited_submenu_colors() {
    $background_colors = get_option('wmo_menu_background_colors', array());
    
    if (empty($background_colors)) {
        return false;
    }
    
    $cleaned_colors = array();
    $removed_items = array();
    
    // Known parent-submenu relationships
    $parent_submenu_map = array(
        'menu-organize' => array('customize-tabs', 'templates', 'reorder-menu', 'settings', 'wp-menu-organize-settings'),
        'dashboard' => array('home', 'updates'),
        'posts' => array('all-posts', 'add-post', 'categories', 'tags'),
        'media' => array('library', 'add-new', 'add-media-file'),
        'pages' => array('all-pages', 'add-page', 'add-new-page'),
        'appearance' => array('themes', 'customize', 'widgets', 'menus', 'theme-editor'),
        'plugins' => array('installed-plugins', 'add-plugin', 'plugin-editor'),
        'users' => array('all-users', 'add-user', 'profile', 'your-profile'),
        'tools' => array('available-tools', 'import', 'export', 'site-health'),
        'settings' => array('general', 'writing', 'reading', 'discussion', 'media-settings', 'permalinks', 'privacy')
    );
    
    // Process all colors
    foreach ($background_colors as $slug => $color) {
        $should_remove = false;
        
        // Check if this is a submenu item that matches its parent's color
        foreach ($parent_submenu_map as $parent => $submenus) {
            if (in_array($slug, $submenus)) {
                // This is a submenu item
                if (isset($background_colors[$parent]) && $background_colors[$parent] === $color) {
                    // Submenu has same color as parent - likely inherited
                    $should_remove = true;
                    $removed_items[] = "$slug (matched parent $parent color: $color)";
                    break;
                }
            }
        }
        
        if (!$should_remove) {
            $cleaned_colors[$slug] = $color;
        }
    }
    
    // Update the option with cleaned colors
    update_option('wmo_menu_background_colors', $cleaned_colors);
    
    return array(
        'original_count' => count($background_colors),
        'cleaned_count' => count($cleaned_colors),
        'removed_count' => count($background_colors) - count($cleaned_colors),
        'removed_items' => $removed_items
    );
}

// Add an AJAX handler for cleanup
function wmo_ajax_cleanup_submenu_colors() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Insufficient permissions');
    }
    
    if (!check_ajax_referer('wmo_ajax_nonce', 'nonce', false)) {
        wp_send_json_error('Invalid nonce');
    }
    
    $result = wmo_cleanup_inherited_submenu_colors();
    
    if ($result) {
        wp_send_json_success(array(
            'message' => 'Submenu colors cleaned successfully',
            'details' => $result
        ));
    } else {
        wp_send_json_error('No colors to clean or cleanup failed');
    }
}
add_action('wp_ajax_wmo_cleanup_submenu_colors', 'wmo_ajax_cleanup_submenu_colors');

// Auto-run cleanup on admin_init once
function wmo_maybe_run_color_cleanup() {
    $cleanup_done = get_option('wmo_color_cleanup_done', false);
    
    if (!$cleanup_done) {
        wmo_cleanup_inherited_submenu_colors();
        update_option('wmo_color_cleanup_done', true);
    }
}
add_action('admin_init', 'wmo_maybe_run_color_cleanup');
?>