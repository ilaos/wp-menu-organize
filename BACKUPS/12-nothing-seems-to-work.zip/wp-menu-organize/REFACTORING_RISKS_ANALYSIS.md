# Refactoring Risks Analysis

## Overview
This document analyzes potential negative impacts of implementing the code consolidation recommendations from the duplication audit.

## 1. CONSOLIDATING SECURITY CHECKS

### Recommendation:
Use `wmo_validate_ajax_request()` everywhere instead of manual checks

### Potential Risks:

#### 1.1 Loss of Granular Control
**Current State:**
```php
// Some functions use custom error messages
if (!current_user_can('manage_options')) {
    wp_send_json_error('You need admin privileges to modify templates');
}
```

**After Consolidation:**
```php
wmo_validate_ajax_request(); // Generic "Insufficient permissions" message
```

**Impact:** 
- Less specific error messages for debugging
- Harder to identify which permission check failed
- May confuse users with generic errors

#### 1.2 Different Response Formats
**Risk:** Some functions use `wp_die()` while others use `wp_send_json_error()`
- Changing all to one format might break frontend JavaScript expecting specific response structures
- AJAX calls might fail silently if error format changes

#### 1.3 Breaking Existing Integrations
- Other plugins or custom code might depend on specific error messages
- Automated testing scripts could break
- Third-party integrations might fail

## 2. MERGING COLOR FUNCTIONS

### Current Functions:
- `wmo_save_color()` - Menu colors
- `wmo_save_background_color()` - Background colors  
- `wmo_save_menu_colors()` - Batch updates

### Potential Risks:

#### 2.1 Database Structure Dependencies
**Risk:** Each function might save to different database fields/options
```php
// Current
update_option('wmo_menu_colors', $colors);        // wmo_save_color
update_option('wmo_menu_background_colors', $bg); // wmo_save_background_color
```
**Impact:**
- Merging could accidentally save to wrong option
- Data migration needed for existing installations
- Risk of color settings being lost

#### 2.2 JavaScript Dependencies
**Risk:** Frontend JS expects specific AJAX actions
```javascript
// Current JavaScript
$.ajax({
    action: 'wmo_save_background_color', // Specific action
    // vs
    action: 'wmo_save_color',           // Different action
});
```
**Impact:**
- Would need to update ALL JavaScript files
- Risk of missing some AJAX calls
- Backward compatibility issues with cached JS

#### 2.3 Different Validation Rules
- Background colors might allow transparency
- Menu colors might have different hex validation
- Batch updates might have rate limiting
- Merging could apply wrong validation rules

## 3. COMBINING IMPORT/EXPORT HANDLERS

### Current Functions:
- `wmo_export_settings_ajax()` - Original settings export
- `wmo_export_configuration()` - New configuration export

### Potential Risks:

#### 3.1 Data Format Incompatibility
**Risk:** Different export formats for backward compatibility
```json
// Old format
{
    "settings": {...}
}

// New format  
{
    "version": "1.0",
    "data": {
        "settings": {...}
    }
}
```
**Impact:**
- Breaking existing exports/backups
- Users unable to import old backups
- Data loss during migration

#### 3.2 Feature Set Differences
- One might export more data than the other
- Different permission requirements
- Different file naming conventions
- Risk of losing functionality

## 4. PERFORMANCE IMPLICATIONS

### 4.1 Function Complexity
**Current:** Simple, focused functions
**After:** Complex functions with many conditional branches
```php
function wmo_unified_save($type, $data) {
    switch($type) {
        case 'color':
            // 50 lines of code
        case 'background':
            // 50 more lines
        case 'batch':
            // 50 more lines
    }
}
```
**Impact:**
- Harder to maintain and debug
- Increased memory usage
- Slower execution
- Higher cognitive load for developers

### 4.2 Testing Complexity
- More edge cases to test
- Harder to isolate bugs
- Increased test suite complexity
- Risk of missing test cases

## 5. BACKWARD COMPATIBILITY ISSUES

### 5.1 Hook Dependencies
Other plugins/themes might use:
```php
remove_action('wp_ajax_wmo_save_color', 'wmo_save_color');
add_action('wp_ajax_wmo_save_color', 'custom_save_color');
```
**Impact:** Breaking third-party customizations

### 5.2 Filter Dependencies
Existing filters might not work:
```php
apply_filters('wmo_before_save_color', $color);
// vs
apply_filters('wmo_before_save', $data); // Too generic
```

## 6. MAINTENANCE RISKS

### 6.1 Git History
- Lose granular commit history for specific features
- Harder to track when specific functionality was added
- Difficult to revert specific changes

### 6.2 Code Clarity
**Current:** Clear, single-purpose functions
**After:** Multi-purpose functions requiring documentation
- New developers need more time to understand
- Higher risk of introducing bugs
- Harder to review pull requests

## 7. RISK MITIGATION STRATEGIES

### Safe Approach:
1. **Keep functions separate but share common logic:**
```php
function wmo_save_color() {
    wmo_validate_ajax_request();
    $data = wmo_sanitize_color_data($_POST);
    // Specific logic here
}
```

2. **Create wrapper functions for backward compatibility:**
```php
function wmo_save_color_legacy() {
    return wmo_unified_color_handler('menu');
}
```

3. **Gradual migration with deprecation notices:**
```php
function wmo_old_function() {
    _deprecated_function(__FUNCTION__, '2.0', 'wmo_new_function');
    return wmo_new_function();
}
```

## 8. RECOMMENDED APPROACH

### DO Consolidate:
✅ Duplicate hook (already fixed)
✅ Common validation logic into helpers
✅ Shared utility functions

### DON'T Consolidate:
❌ Different AJAX endpoints (keep separate for clarity)
❌ Different data structures (maintain compatibility)
❌ Functions with different business logic

### Careful Consolidation:
⚠️ Security checks (use helper but allow custom messages)
⚠️ Import/export (share code but keep endpoints)
⚠️ Color functions (share validation but keep handlers)

## CONCLUSION

**Recommendation:** Proceed with PARTIAL consolidation:
1. Fix obvious duplicates (✅ done)
2. Extract shared logic to helpers
3. Keep separate endpoints for backward compatibility
4. Add deprecation notices for future cleanup
5. Document all changes thoroughly

**Estimated Risk Level:** 
- Full consolidation: HIGH RISK ⚠️
- Partial consolidation: LOW RISK ✅
- No changes: ZERO RISK (but technical debt remains)