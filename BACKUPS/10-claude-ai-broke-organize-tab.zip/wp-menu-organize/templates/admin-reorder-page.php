<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Security check
if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.', 'wp-menu-organize'));
}

// Declare global $menu early
global $menu;

// Check if $menu is empty or not an array
if (!is_array($menu) || empty($menu)) {
    echo '<div class="wrap"><div class="notice notice-error"><p><strong>Error:</strong> Global $menu is empty or not an array. This indicates a WordPress core issue or plugin conflict.</p></div></div>';
    return;
}

// Get current menu order from settings (flat structure)
$saved_order = wmo_get_settings('menu_order');
$saved_order = is_array($saved_order) ? $saved_order : array();

// Filter out separators and empty items, preserve exact slugs
$valid_menu_items = array();
$processed_count = 0;

foreach ($menu as $menu_item) {
    $processed_count++;
    
    // Skip separators and empty items
    if (empty($menu_item[0]) || empty($menu_item[2]) || $menu_item[2] === 'separator') {
        continue;
    }
    $valid_menu_items[] = $menu_item;
}

// Apply saved order if available - improved logic
if (!empty($saved_order) && count($saved_order) > 0) {
    $ordered_items = array();
    $unordered_items = array();
    
    // First, add items in saved order (preserve exact slugs)
    foreach ($saved_order as $slug) {
        foreach ($valid_menu_items as $key => $item) {
            if ($item[2] === $slug) {
                $ordered_items[] = $item;
                unset($valid_menu_items[$key]);
                break;
            }
        }
    }
    
    // Then add any remaining items in their original order
    foreach ($valid_menu_items as $item) {
        $unordered_items[] = $item;
    }
    
    $valid_menu_items = array_merge($ordered_items, $unordered_items);
}

// Create array of final slugs for debug display
$final_slugs = array();
foreach ($valid_menu_items as $item) {
    if (isset($item[2]) && !empty($item[2])) {
        $final_slugs[] = $item[2];
    }
}

?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="wmo-instructions">
        <p><strong>✨ Optimize your workflow:</strong> Drag items to arrange your menu in the order that works best for you. Your most-used pages should be easily accessible.</p>
        <p><em>Tip: Click and drag the menu item titles to reorder them. Changes are saved automatically when you drag items.</em></p>
    </div>

    <?php if (empty($valid_menu_items)): ?>
        <div class="notice notice-warning">
            <p><strong>No menu items found to reorder.</strong> This might be due to insufficient permissions or the menu not being loaded properly.</p>
            <p>Debug info: Processed <?php echo $processed_count; ?> items, found <?php echo count($valid_menu_items); ?> valid items.</p>
            <p>Check global $menu: <?php echo is_array($menu) ? 'Array with ' . count($menu) . ' items' : 'Not an array'; ?></p>
        </div>
    <?php else: ?>
        <form method="post" id="wmo-reorder-form">
            <?php wp_nonce_field('wmo_save_menu_order', 'wmo_nonce'); ?>
            
            <!-- Main sortable container with proper class -->
            <div class="menu-items-list">
                <ul id="wmo-sortable-menu">
                    <?php foreach ($valid_menu_items as $menu_item): ?>
                        <?php
                        // Extract menu item data - preserve exact slugs
                        $menu_title = strip_tags($menu_item[0]);
                        $menu_slug = $menu_item[2]; // Use exact slug (e.g., 'index.php', 'edit.php')
                        $menu_icon = isset($menu_item[6]) ? $menu_item[6] : 'dashicons-admin-generic';
                        
                        // Skip if no title or slug
                        if (empty($menu_title) || empty($menu_slug)) {
                            continue;
                        }
                        ?>
                        <li class="menu-item" data-slug="<?php echo esc_attr($menu_slug); ?>">
                            <div class="menu-item-handle">
                                <span class="dashicons <?php echo esc_attr($menu_icon); ?>"></span>
                                <span class="item-title"><?php echo esc_html($menu_title); ?></span>
                                <span class="item-controls">
                                    <span class="drag-hint"><?php _e('Drag to reorder', 'wp-menu-organize'); ?></span>
                                </span>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="wmo-actions">
                <p class="submit">
                    <button type="button" id="wmo-refresh-page" class="button button-primary">
                        <span class="dashicons dashicons-update"></span>
                        <?php _e('Refresh Page to Apply Changes', 'wp-menu-organize'); ?>
                    </button>
                    <button type="button" id="wmo-reset-order" class="button button-secondary">
                        <span class="dashicons dashicons-image-rotate"></span>
                        <?php _e('Reset to Default', 'wp-menu-organize'); ?>
                    </button>
                    <span id="wmo-save-status" class="wmo-status"></span>
                </p>
                <p class="description">
                    <em><?php _e('Changes are saved automatically when you drag items. Click "Refresh Page to Apply Changes" to see the new order in the WordPress admin sidebar.', 'wp-menu-organize'); ?></em>
                </p>
            </div>
        </form>

        <div class="wmo-debug-info" style="display: none;">
            <h3><?php _e('Debug Information', 'wp-menu-organize'); ?></h3>
            <p><strong><?php _e('Total menu items:', 'wp-menu-organize'); ?></strong> <?php echo count($valid_menu_items); ?></p>
            <p><strong><?php _e('Saved order items:', 'wp-menu-organize'); ?></strong> <?php echo count($saved_order); ?></p>
            <p><strong><?php _e('Current page:', 'wp-menu-organize'); ?></strong> <?php echo esc_html($_GET['page'] ?? 'unknown'); ?></p>
            <p><strong><?php _e('Global menu count:', 'wp-menu-organize'); ?></strong> <?php echo count($menu); ?></p>
            <p><strong><?php _e('Final order slugs:', 'wp-menu-organize'); ?></strong> <?php echo esc_html(implode(', ', $final_slugs)); ?></p>
        </div>
    <?php endif; ?>
</div>

<style>
/* Modern Reorder Menu Design */
.wrap {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    padding: 30px;
    border-radius: 20px;
    margin: 20px 20px 20px 0;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
}

.wrap h1 {
    color: #fff !important;
    font-size: 32px;
    font-weight: 700;
    margin-bottom: 10px;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
}

.wmo-instructions {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border: none;
    border-radius: 15px;
    padding: 20px 25px;
    margin-bottom: 25px;
    box-shadow: 0 8px 32px rgba(31, 38, 135, 0.15);
}

.wmo-instructions p {
    color: #4a5568;
    font-size: 15px;
    line-height: 1.6;
}

.menu-items-list {
    max-width: 900px;
    margin: 30px 0;
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 15px 50px rgba(0,0,0,0.2);
}

#wmo-sortable-menu {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 12px;
}

/* Modern Menu Item Cards */
#wmo-sortable-menu .menu-item {
    background: linear-gradient(135deg, #ffffff 0%, #f7fafc 100%);
    border: 2px solid transparent;
    border-radius: 15px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.07), 0 1px 3px rgba(0,0,0,0.06);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
    min-height: 70px;
}

#wmo-sortable-menu .menu-item::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
    transform: scaleX(0);
    transition: transform 0.3s ease;
}

#wmo-sortable-menu .menu-item:hover {
    transform: translateY(-3px) scale(1.01);
    box-shadow: 0 12px 24px rgba(102, 126, 234, 0.15), 0 4px 8px rgba(0,0,0,0.1);
    border-color: rgba(102, 126, 234, 0.3);
}

#wmo-sortable-menu .menu-item:hover::before {
    transform: scaleX(1);
}

/* SortableJS Ghost Element - The dragged item preview */
.sortable-ghost {
    opacity: 0.4;
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(124, 58, 237, 0.1) 100%);
    transform: scale(1.02);
    box-shadow: 0 15px 40px rgba(102, 126, 234, 0.3);
}

/* SortableJS Drag State - Applied to original element while dragging */
.sortable-drag {
    opacity: 0.5;
}

/* SortableJS Chosen State - When initially clicked */
.sortable-chosen {
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(124, 58, 237, 0.05) 100%);
}

/* Additional dragging state for visual feedback */
#wmo-sortable-menu .menu-item.is-dragging {
    cursor: grabbing !important;
}

/* Enhanced Menu Handle */
.menu-item-handle {
    display: flex;
    align-items: center;
    padding: 20px 25px;
    cursor: grab;
    user-select: none;
    position: relative;
}

.menu-item-handle:active {
    cursor: grabbing;
}

/* Grip Indicator */
.menu-item-handle::before {
    content: '⋮⋮';
    position: absolute;
    left: 10px;
    color: #cbd5e0;
    font-size: 18px;
    font-weight: 900;
    letter-spacing: -3px;
    transition: color 0.3s ease;
}

.menu-item:hover .menu-item-handle::before {
    color: #667eea;
}

.menu-item-handle .dashicons {
    margin: 0 15px 0 25px;
    color: #667eea;
    width: 24px;
    height: 24px;
    font-size: 20px;
    transition: transform 0.3s ease;
}

.menu-item:hover .menu-item-handle .dashicons {
    transform: scale(1.1);
}

.item-title {
    flex: 1;
    font-weight: 600;
    color: #2d3748;
    font-size: 16px;
    letter-spacing: -0.025em;
}

.item-controls {
    margin-left: auto;
    display: flex;
    align-items: center;
    gap: 8px;
}

.drag-hint {
    color: #a0aec0;
    font-size: 11px;
    font-style: normal;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    background: rgba(102, 126, 234, 0.1);
    padding: 4px 10px;
    border-radius: 20px;
}

/* Modern Action Panel */
.wmo-actions {
    margin-top: 30px;
    padding: 25px;
    background: linear-gradient(135deg, rgba(255,255,255,0.95) 0%, rgba(249,250,251,0.95) 100%);
    backdrop-filter: blur(10px);
    border: 2px solid rgba(102, 126, 234, 0.1);
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

/* Modern Buttons */
.wmo-actions button {
    margin-right: 15px;
    padding: 12px 30px !important;
    font-size: 15px !important;
    font-weight: 600 !important;
    border-radius: 10px !important;
    border: none !important;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

/* Save Button - Primary */
#wmo-save-order {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    color: white !important;
    box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3) !important;
}

#wmo-save-order:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 6px 25px rgba(102, 126, 234, 0.4) !important;
}

/* Reset Button */
#wmo-reset-order {
    background: rgba(255, 255, 255, 0.9) !important;
    color: #667eea !important;
    border: 2px solid #667eea !important;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05) !important;
}

#wmo-reset-order:hover {
    background: #667eea !important;
    color: white !important;
    transform: translateY(-2px) !important;
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.3) !important;
}

/* Refresh Button */
#wmo-refresh-menu {
    background: linear-gradient(135deg, #48bb78 0%, #38a169 100%) !important;
    color: white !important;
    border: none !important;
    box-shadow: 0 4px 15px rgba(72, 187, 120, 0.3) !important;
}

#wmo-refresh-menu:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 6px 25px rgba(72, 187, 120, 0.4) !important;
}

/* Status Messages */
.wmo-status {
    margin-left: 15px;
    font-weight: 600;
    font-size: 14px;
    padding: 8px 15px;
    border-radius: 8px;
    display: inline-block;
    transition: all 0.3s ease;
}

.wmo-status.loading {
    background: rgba(102, 126, 234, 0.1);
    color: #667eea;
    animation: statusPulse 1.5s ease-in-out infinite;
}

.wmo-status.success {
    background: linear-gradient(135deg, rgba(72, 187, 120, 0.1) 0%, rgba(56, 161, 105, 0.1) 100%);
    color: #38a169;
    animation: successBounce 0.5s ease;
}

.wmo-status.error {
    background: rgba(245, 101, 101, 0.1);
    color: #f56565;
    animation: errorShake 0.5s ease;
}

@keyframes statusPulse {
    0%, 100% { opacity: 0.7; }
    50% { opacity: 1; }
}

@keyframes successBounce {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
}

@keyframes errorShake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-5px); }
    75% { transform: translateX(5px); }
}

/* Already styled above */
.wmo-instructions p {
    margin: 0 0 10px 0;
}

.wmo-instructions p:last-child {
    margin-bottom: 0;
}

.wmo-debug-info {
    margin-top: 30px;
    padding: 15px;
    background: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 4px;
}

.wmo-debug-info h3 {
    margin-top: 0;
    color: #666;
}

.wmo-notice {
    position: fixed;
    top: 32px;
    right: 20px;
    z-index: 9999;
    max-width: 300px;
    padding: 10px 15px;
    border-radius: 4px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    animation: wmo-slide-in 0.3s ease-out;
}

.wmo-notice.success {
    background: #46b450;
    color: white;
}

.wmo-notice.error {
    background: #dc3232;
    color: white;
}

@keyframes wmo-slide-in {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}
</style>

<script type="text/javascript">
jQuery(document).ready(function($) {
    // COORDINATION FLAGS - Prevent double initialization
    if (window.wmoTemplateInitialized) {
        console.log('WMO: Template already initialized, skipping duplicate initialization');
        return;
    }
    window.wmoTemplateInitialized = true;
    
    // saveMenuOrder is defined in admin.js, just use it if available
    if (typeof window.saveMenuOrder !== 'function') {
        // Fallback if admin.js hasn't loaded yet
        window.saveMenuOrder = function() {
            console.log('WMO: SaveMenuOrder will be initialized by admin.js');
        };
    }
    
    // Reset order function
    function resetMenuOrder() {
        if (!confirm('<?php _e('Are you sure you want to reset the menu order to default? This action cannot be undone.', 'wp-menu-organize'); ?>')) {
            return;
        }
        
        var $status = $('#wmo-save-status');
        var $resetButton = $('#wmo-reset-order');
        
        $status.removeClass('success error').addClass('loading').text('Resetting...');
        $resetButton.prop('disabled', true);
        
        // Check if wmo_ajax is defined, fallback to admin-ajax.php
        var ajaxUrl = (typeof wmo_ajax !== 'undefined' && wmo_ajax.ajax_url) ? wmo_ajax.ajax_url : ajaxurl;
        var nonce = (typeof wmo_ajax !== 'undefined' && wmo_ajax.nonce) ? wmo_ajax.nonce : '<?php echo wp_create_nonce('wmo_ajax_nonce'); ?>';
        
        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                action: 'wmo_reset_menu_order',
                nonce: nonce
            },
            success: function(response) {
                if (response.success) {
                    $status.removeClass('loading error').addClass('success').text('Menu order reset successfully!');
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                } else {
                    $status.removeClass('loading success').addClass('error').text('Error resetting menu order: ' + (response.data || 'Unknown error'));
                }
            },
            error: function() {
                $status.removeClass('loading success').addClass('error').text('Network error while resetting menu order');
            },
            complete: function() {
                $resetButton.prop('disabled', false);
            }
        });
    }
    
    // Event handlers
    $('#wmo-refresh-page').on('click', function() {
        if (confirm('<?php _e('Refresh the page to apply menu order changes to the WordPress admin sidebar?', 'wp-menu-organize'); ?>')) {
            window.location.reload();
        }
    });
    $('#wmo-reset-order').on('click', resetMenuOrder);
    
    // Initialize SortableJS when ready
    function initializeSortable() {
        // Check if admin.js has already initialized it
        if (window.wmoSortableInitialized) {
            console.log('WMO: SortableJS already initialized by admin.js');
            return;
        }
        
        // Check if SortableJS is available
        if (typeof Sortable === 'undefined') {
            console.log('WMO: Waiting for SortableJS to load...');
            setTimeout(initializeSortable, 100);
            return;
        }
        
        // Check if wmoInitializeSortable is available from admin.js
        if (typeof window.wmoInitializeSortable === 'function') {
            console.log('WMO: Initializing SortableJS via admin.js');
            window.wmoInitializeSortable();
        } else {
            console.log('WMO: Waiting for admin.js to load...');
            setTimeout(initializeSortable, 100);
        }
    }
    
    // Start initialization
    initializeSortable();
});
</script>