<?php
/**
 * Admin Settings Page Template - Custom Order Version
 * This version respects the custom menu order from Reorder Menu
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Check if $menu_for_display is available from admin-page.php
$display_menu = isset($menu_for_display) ? $menu_for_display : $menu;
?>

<div class="wrap wmo-settings-wrap">
    <h1>
        <span class="dashicons dashicons-menu"></span>
        <?php echo esc_html(get_admin_page_title()); ?>
    </h1>
    
    <div class="wmo-settings-container">
        <form method="post" action="options.php">
            <?php settings_fields('wmo_settings_group'); ?>
            
            <div class="wmo-section">
                <h2 class="wmo-section-title">
                    <span class="dashicons dashicons-art"></span>
                    <?php _e('Menu Item Colors', 'wp-menu-organize'); ?>
                </h2>
                
                <div class="wmo-instructions">
                    <p><?php _e('Customize the colors of your admin menu items. Leave blank to use default colors.', 'wp-menu-organize'); ?></p>
                    <p><em><?php _e('Note: Menu items are displayed in your custom order from the Reorder Menu page.', 'wp-menu-organize'); ?></em></p>
                </div>
                
                <div class="wmo-color-groups">
                    <div class="wmo-all-menu-items">
                        <?php
                        // Process all menu items in custom order
                        if (isset($display_menu) && is_array($display_menu)) {
                            $item_count = 0;
                            foreach ($display_menu as $menu_item) {
                                // Skip separators and empty items
                                if (empty($menu_item[0]) || empty($menu_item[2]) || $menu_item[2] === 'separator') {
                                    continue;
                                }
                                
                                $menu_slug = sanitize_title(strip_tags($menu_item[0]));
                                if (empty($menu_slug)) continue;
                                
                                $menu_title = preg_replace('/\d+/', '', strip_tags($menu_item[0]));
                                $menu_title = trim($menu_title);
                                $menu_file = $menu_item[2];
                                
                                // Check if this item has submenus
                                $has_submenus = isset($submenu[$menu_file]) && !empty($submenu[$menu_file]);
                                
                                // Determine item type for styling
                                $core_items = ['dashboard', 'posts', 'media', 'pages', 'comments'];
                                $site_mgmt_items = ['appearance', 'plugins', 'users', 'tools', 'settings'];
                                
                                $item_type = 'plugin';
                                if (in_array($menu_slug, $core_items)) {
                                    $item_type = 'core';
                                } elseif (in_array($menu_slug, $site_mgmt_items)) {
                                    $item_type = 'site';
                                }
                                
                                $item_count++;
                                ?>
                                <div class="wmo-color-group wmo-menu-item-group <?php echo $has_submenus ? 'has-submenus' : 'no-submenus'; ?> item-type-<?php echo $item_type; ?>">
                                    <div class="wmo-menu-item-header">
                                        <span class="item-number"><?php echo $item_count; ?>.</span>
                                        <h3>
                                            <?php 
                                            // Add appropriate icon based on type
                                            if ($item_type === 'core') {
                                                echo '<span class="dashicons dashicons-dashboard"></span> ';
                                            } elseif ($item_type === 'site') {
                                                echo '<span class="dashicons dashicons-admin-appearance"></span> ';
                                            } else {
                                                echo '<span class="dashicons dashicons-admin-plugins"></span> ';
                                            }
                                            echo esc_html($menu_title);
                                            if ($has_submenus) {
                                                echo ' <span class="submenu-indicator">(+' . count($submenu[$menu_file]) . ' submenus)</span>';
                                            }
                                            ?>
                                        </h3>
                                    </div>
                                    
                                    <div class="wmo-menu-item-colors">
                                        <!-- Parent item color picker -->
                                        <div class="wmo-parent-item">
                                            <?php wmo_render_color_picker($menu_colors, $menu_slug, $menu_title . ($has_submenus ? ' (Parent)' : '')); ?>
                                        </div>
                                        
                                        <!-- Submenu items if they exist -->
                                        <?php if ($has_submenus && !empty($submenu[$menu_file])): ?>
                                            <div class="wmo-submenu-items">
                                                <?php foreach ($submenu[$menu_file] as $subitem): ?>
                                                    <?php 
                                                    $submenu_slug = sanitize_title(strip_tags($subitem[0]));
                                                    $submenu_title = strip_tags($subitem[0]);
                                                    if (!empty($submenu_slug)) {
                                                        wmo_render_color_picker($menu_colors, $submenu_slug, $submenu_title, true);
                                                    }
                                                    ?>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
            
            <p class="submit">
                <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php _e('Save Changes', 'wp-menu-organize'); ?>">
                <button type="button" class="button button-secondary" id="wmo-reset-colors">
                    <?php _e('Reset All Colors', 'wp-menu-organize'); ?>
                </button>
            </p>
        </form>
    </div>
</div>

<style>
/* Additional styles for ordered display */
.wmo-all-menu-items {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20px;
    margin-top: 20px;
}

/* Responsive adjustments */
@media screen and (max-width: 1400px) {
    .wmo-all-menu-items {
        grid-template-columns: 1fr;
    }
}

@media screen and (min-width: 1800px) {
    .wmo-all-menu-items {
        grid-template-columns: repeat(3, 1fr);
    }
}

.wmo-menu-item-group {
    background: white;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 15px;
    transition: all 0.3s ease;
    position: relative;
    overflow: visible; /* Allow dropdowns to overflow */
}

.wmo-menu-item-group:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    transform: translateY(-2px);
    z-index: 10; /* Bring to front when hovering */
}

.wmo-menu-item-group.item-type-core {
    border-left: 4px solid #2271b1;
}

.wmo-menu-item-group.item-type-site {
    border-left: 4px solid #00a32a;
}

.wmo-menu-item-group.item-type-plugin {
    border-left: 4px solid #8c5cff;
}

.wmo-menu-item-header {
    display: flex;
    align-items: center;
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid #f0f0f0;
}

.item-number {
    background: #f0f0f0;
    color: #666;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    margin-right: 10px;
}

.wmo-menu-item-header h3 {
    margin: 0;
    font-size: 16px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.submenu-indicator {
    font-size: 12px;
    color: #999;
    font-weight: normal;
}

.wmo-submenu-items {
    margin-top: 10px;
    padding-left: 20px;
    border-left: 2px solid #f0f0f0;
}

.wmo-instructions {
    background: #f6f7f7;
    border-left: 4px solid #2271b1;
    padding: 12px;
    margin: 20px 0;
}

.wmo-instructions p {
    margin: 5px 0;
}

.wmo-instructions em {
    color: #666;
}

/* Ensure color picker dropdowns don't get cut off */
.wmo-menu-item-colors {
    position: relative;
    z-index: 1;
}

.wmo-color-picker-wrapper {
    position: relative;
}

/* WordPress color picker specific adjustments */
.wp-picker-container {
    position: relative;
    z-index: 100;
}

.wp-picker-container.wp-picker-active {
    z-index: 200;
}

/* Ensure the color picker dropdown is visible */
.wp-picker-holder {
    position: absolute !important;
    z-index: 1000 !important;
}

/* Fix for last items in grid */
.wmo-menu-item-group:nth-last-child(-n+2) .wp-picker-holder {
    bottom: auto !important;
    top: auto !important;
}

/* Ensure dropdowns in last row open upward if needed */
.wmo-all-menu-items > :last-child .wp-picker-holder,
.wmo-all-menu-items > :nth-last-child(2) .wp-picker-holder {
    /* Allow picker to determine best position */
    position: absolute !important;
}

/* Add some padding at bottom to accommodate dropdowns */
.wmo-settings-container {
    padding-bottom: 300px;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Reset colors functionality
    $('#wmo-reset-colors').on('click', function() {
        if (confirm('<?php _e('Are you sure you want to reset all menu colors to default?', 'wp-menu-organize'); ?>')) {
            $('.wmo-color-picker').each(function() {
                $(this).wpColorPicker('color', '');
            });
        }
    });
});
</script>