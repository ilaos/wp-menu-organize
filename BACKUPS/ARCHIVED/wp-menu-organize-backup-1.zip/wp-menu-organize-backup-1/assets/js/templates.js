﻿// WP Menu Organize - Templates System
(function($) {
    'use strict';

    // Initialize when document is ready
    $(function() {
        if ($('#wmo-templates-gallery').length > 0) {
            initTemplatesFunctionality();
        }
    });

    // Initialize templates functionality
    function initTemplatesFunctionality() {
        console.log('WMO: Initializing templates functionality');
        wmoLoadTemplates('all');
    }

    // Load templates from server
    function wmoLoadTemplates(category) {
        console.log('WMO: Loading templates for category:', category);
        
        var $gallery = $('#wmo-templates-gallery');
        $gallery.html('<div class="wmo-templates-loading"><span class="dashicons dashicons-update-alt wmo-spin"></span> Loading templates...</div>');

        $.ajax({
            url: wmo_ajax.ajax_url,
            method: 'POST',
            data: {
                action: 'wmo_load_templates',
                category: category,
                nonce: wmo_ajax.nonce
            },
            success: function(response) {
                console.log('WMO: AJAX response:', response);
                if (response.success) {
                    console.log('WMO: Templates:', response.data.templates);
                    wmoRenderTemplates(response.data.templates);
                } else {
                    console.error('WMO: Failed to load templates:', response.data);
                    $gallery.html('<div class="wmo-templates-error">Failed to load templates: ' + response.data + '</div>');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('WMO: AJAX error:', textStatus, errorThrown);
                $gallery.html('<div class="wmo-templates-error">Failed to load templates. Please refresh the page.</div>');
            }
        });
    }

    // Render templates on the page
    function wmoRenderTemplates(templates) {
        console.log('WMO: Rendering', templates.length, 'templates');
        console.log('WMO: Template data:', templates);
        
        var $gallery = $('#wmo-templates-gallery');
        
        if (templates.length === 0) {
            $gallery.html('<div class="wmo-templates-empty">No templates found.</div>');
            return;
        }

        var html = '<div class="wmo-templates-grid">';
        
        templates.forEach(function(template, index) {
            console.log('WMO: Template', index, ':', template);
            console.log('WMO: Template', index, 'category:', template.category);
            console.log('WMO: Template', index, 'preview:', template.preview);
            
            html += '<div class="wmo-template-card" data-template-id="' + (template.id || '') + '">';
            html += '  <h4>' + (template.name || 'Untitled Template') + '</h4>';
            html += '  <div class="wmo-template-category">' + (template.category || 'General') + '</div>';
            html += '  <div class="wmo-template-description">' + (template.description || 'No description available') + '</div>';
            html += '  <div class="wmo-template-preview">' + (template.preview || 'Preview not available') + '</div>';
            html += '  <div class="wmo-template-actions">';
            html += '    <button type="button" class="button button-primary wmo-apply-template" data-template-id="' + (template.id || '') + '">Apply Template</button>';
            html += '  </div>';
            html += '</div>';
        });
        
        html += '</div>';
        $gallery.html(html);
        
        // Attach event handlers to the Apply Template buttons
        $gallery.find('.wmo-apply-template').on('click', function() {
            var templateId = $(this).data('template-id');
            console.log('WMO: Applying template:', templateId);
            wmoApplyTemplate(templateId);
        });
        
        console.log('WMO: Templates rendered successfully!');
    }

    // Apply template functionality
    function wmoApplyTemplate(templateId) {
        console.log('WMO: Applying template with ID:', templateId);
        
        // Show loading state
        var $button = $('.wmo-apply-template[data-template-id="' + templateId + '"]');
        var originalText = $button.text();
        $button.text('Applying...').prop('disabled', true);
        
        $.ajax({
            url: wmo_ajax.ajax_url,
            method: 'POST',
            data: {
                action: 'wmo_apply_template',
                template_id: templateId,
                nonce: wmo_ajax.nonce
            },
            success: function(response) {
                console.log('WMO: Apply template response:', response);
                if (response.success) {
                    // Show success message
                    $button.text('Applied!').removeClass('button-primary').addClass('button-secondary');
                    setTimeout(function() {
                        $button.text(originalText).removeClass('button-secondary').addClass('button-primary').prop('disabled', false);
                    }, 2000);
                    
                    // Optionally reload the page or show a notification
                    alert('Template applied successfully!');
                } else {
                    console.error('WMO: Failed to apply template:', response.data);
                    $button.text('Error').removeClass('button-primary').addClass('button-secondary');
                    setTimeout(function() {
                        $button.text(originalText).removeClass('button-secondary').addClass('button-primary').prop('disabled', false);
                    }, 2000);
                    alert('Failed to apply template: ' + response.data);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('WMO: Apply template error:', textStatus, errorThrown);
                $button.text('Error').removeClass('button-primary').addClass('button-secondary');
                setTimeout(function() {
                    $button.text(originalText).removeClass('button-secondary').addClass('button-primary').prop('disabled', false);
                }, 2000);
                alert('Error applying template. Please try again.');
            }
        });
    }

})(jQuery);
