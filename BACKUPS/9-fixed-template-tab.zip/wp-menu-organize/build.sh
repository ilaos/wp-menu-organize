#!/bin/bash

# WMO Plugin Build Script
# This script minifies CSS and JavaScript files for better performance

echo "🔧 WMO Plugin Build Script"
echo "=========================="

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js to use this build script."
    echo "   You can download it from: https://nodejs.org/"
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install npm to use this build script."
    exit 1
fi

# Check if package.json exists
if [ ! -f "package.json" ]; then
    echo "❌ package.json not found. Please run this script from the plugin root directory."
    exit 1
fi

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
fi

# Run the build process
echo "🚀 Running build process..."
npm run build

# Show results
echo ""
echo "🎉 Build complete!"
echo ""
echo "📊 File sizes:"

# Calculate and display size savings
if [ -f "assets/src/css/admin.css" ] && [ -f "assets/dist/css/admin.min.css" ]; then
    ORIGINAL_CSS=$(wc -c < "assets/src/css/admin.css")
    MINIFIED_CSS=$(wc -c < "assets/dist/css/admin.min.css")
    CSS_SAVINGS=$((ORIGINAL_CSS - MINIFIED_CSS))
    CSS_PERCENT=$((CSS_SAVINGS * 100 / ORIGINAL_CSS))
    echo "   admin.css: ${ORIGINAL_CSS} bytes → ${MINIFIED_CSS} bytes (${CSS_PERCENT}% smaller)"
fi

if [ -f "assets/src/js/admin.js" ] && [ -f "assets/dist/js/admin.min.js" ]; then
    ORIGINAL_JS=$(wc -c < "assets/src/js/admin.js")
    MINIFIED_JS=$(wc -c < "assets/dist/js/admin.min.js")
    JS_SAVINGS=$((ORIGINAL_JS - MINIFIED_JS))
    JS_PERCENT=$((JS_SAVINGS * 100 / ORIGINAL_JS))
    echo "   admin.js: ${ORIGINAL_JS} bytes → ${MINIFIED_JS} bytes (${JS_PERCENT}% smaller)"
fi

if [ -f "assets/src/js/color-picker.js" ] && [ -f "assets/dist/js/color-picker.min.js" ]; then
    ORIGINAL_CP=$(wc -c < "assets/src/js/color-picker.js")
    MINIFIED_CP=$(wc -c < "assets/dist/js/color-picker.min.js")
    CP_SAVINGS=$((ORIGINAL_CP - MINIFIED_CP))
    CP_PERCENT=$((CP_SAVINGS * 100 / ORIGINAL_CP))
    echo "   color-picker.js: ${ORIGINAL_CP} bytes → ${MINIFIED_CP} bytes (${CP_PERCENT}% smaller)"
fi

echo ""
echo "💡 Tips:"
echo "   • The plugin automatically uses minified files in production"
echo "   • For development, add to wp-config.php: define('SCRIPT_DEBUG', true);"
echo "   • Run 'npm run watch' to automatically rebuild on file changes"
echo "   • Run 'npm run lint' to check JavaScript code quality"