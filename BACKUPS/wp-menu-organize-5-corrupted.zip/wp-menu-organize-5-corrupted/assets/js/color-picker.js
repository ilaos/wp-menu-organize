﻿(function($) {
    'use strict';

    // Debounce function for performance optimization
    function debounce(func, wait, immediate) {
        var timeout;
        return function() {
            var context = this, args = arguments;
            var later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            var callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    }

    // Initialize inline color picker functionality
    function initInlineColorPicker() {
        console.log('WMO: Initializing inline color picker functionality');
        
        // Handle color swatch clicks
        $(document).on('click', '.color-swatch', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            var $swatch = $(this);
            var itemId = $swatch.data('item-id');
            var currentColor = $swatch.css('background-color');
            
            console.log('WMO: Color swatch clicked for item:', itemId, 'Current color:', currentColor);
            
            // Disable sortable during color picker
            var $sortableMenu = $('#wmo-sortable-menu');
            if ($sortableMenu.hasClass('ui-sortable')) {
                $sortableMenu.sortable('disable');
            }
            
            // Create color picker input
            var $colorInput = $('<input type="text" class="inline-color-picker" value="" style="position: absolute; opacity: 0; pointer-events: none;">');
            
            // Position the input near the swatch
            $swatch.css('position', 'relative').append($colorInput);
            
            // Initialize WordPress Color Picker
            if ($.fn.wpColorPicker) {
                $colorInput.wpColorPicker({
                    defaultColor: currentColor !== 'transparent' ? currentColor : '#000000',
                    change: debounce(function(event, ui) {
                        var newColor = ui.color.toString();
                        console.log('WMO: Color changed to:', newColor);
                        
                        // Update swatch background
                        $swatch.css('background-color', newColor);
                        
                        // Save color via AJAX
                        saveInlineColor(itemId, newColor, $swatch);
                    }, 300), // Debounce for performance
                    clear: function() {
                        console.log('WMO: Color cleared');
                        // Handle color clear (set to transparent)
                        $swatch.css('background-color', 'transparent');
                        saveInlineColor(itemId, '', $swatch);
                    }
                });
                
                // Show the color picker
                $colorInput.wpColorPicker('open');
                
                // Handle color picker close
                $(document).on('click.wmoColorPicker', function(e) {
                    if (!$(e.target).closest('.wp-color-result, .wp-picker-container').length) {
                        closeColorPicker($colorInput, $sortableMenu);
                    }
                });
                
                // Handle escape key
                $(document).on('keydown.wmoColorPicker', function(e) {
                    if (e.keyCode === 27) { // Escape key
                        closeColorPicker($colorInput, $sortableMenu);
                    }
                });
                
            } else {
                console.error('WMO: WordPress Color Picker not available');
                alert('Color picker not available. Please ensure WordPress Color Picker is loaded.');
                reEnableSortable($sortableMenu);
            }
        });
    }
    
    // Function to save inline color
    function saveInlineColor(itemId, color, $swatch) {
        console.log('WMO: Saving inline color for item:', itemId, 'Color:', color);
        
        // Add loading state
        $swatch.addClass('edit-loading');
        
        // Show spinner
        var $spinner = $('<span class="edit-spinner">â³</span>');
        $swatch.append($spinner);
        
        $.ajax({
            url: wmo_ajax.ajax_url,
            method: 'POST',
            data: {
                action: 'wmo_save_color',
                id: itemId,
                color: color,
                nonce: wmo_ajax.nonce
            },
            success: function(response) {
                console.log('WMO: Color save response:', response);
                
                if (response.success) {
                    // Show success feedback
                    showInlineFeedback($swatch, 'Color saved!', 'success');
                    console.log('WMO: Color saved successfully');
                } else {
                    // Show error feedback
                    var errorMsg = 'Error saving color';
                    if (response.data && response.data.message) {
                        errorMsg = response.data.message;
                    }
                    showInlineFeedback($swatch, errorMsg, 'error');
                    console.error('WMO: Color save failed:', response.data);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('WMO: Color save AJAX error:', textStatus, errorThrown);
                
                // Show error feedback
                var errorMsg = 'Network error';
                if (jqXHR.responseJSON && jqXHR.responseJSON.data && jqXHR.responseJSON.data.message) {
                    errorMsg = jqXHR.responseJSON.data.message;
                }
                showInlineFeedback($swatch, errorMsg, 'error');
            },
            complete: function() {
                $swatch.removeClass('edit-loading');
                $spinner.remove();
            }
        });
    }
    
    // Function to close color picker
    function closeColorPicker($colorInput, $sortableMenu) {
        console.log('WMO: Closing color picker');
        
        // Remove event listeners
        $(document).off('click.wmoColorPicker keydown.wmoColorPicker');
        
        // Remove color input
        $colorInput.remove();
        
        // Re-enable sortable
        reEnableSortable($sortableMenu);
    }
    
    // Function to re-enable sortable
    function reEnableSortable($sortableMenu) {
        if ($sortableMenu.hasClass('ui-sortable')) {
            $sortableMenu.sortable('enable');
        }
    }
    
    // Function to show inline feedback
    function showInlineFeedback($element, message, type) {
        var $feedback = $('<div class="edit-' + type + '">' + message + '</div>');
        $element.css('position', 'relative').append($feedback);
        
        // Show feedback
        setTimeout(function() {
            $feedback.addClass('show');
        }, 10);
        
        // Hide feedback after 3 seconds
        setTimeout(function() {
            $feedback.removeClass('show');
            setTimeout(function() {
                $feedback.remove();
            }, 300);
        }, 3000);
    }
    
    // Initialize when document is ready
    $(function() {
        console.log('Color picker JS loaded');
        console.log('Found color fields:', $('.color-field').length);
        console.log('Found wmo-color-field:', $('.wmo-color-field').length);
        
        // STEP 1: Monitor ALL AJAX calls
        $(document).ajaxSend(function(event, xhr, settings) {
            if (settings.data && settings.data.includes('wmo_')) {
                console.log('WMO AJAX Send:', settings.data);
            }
        });
        
        $(document).ajaxComplete(function(event, xhr, settings) {
            if (settings.data && settings.data.includes('wmo_')) {
                console.log('WMO AJAX Response:', xhr.responseText);
            }
        });
        
        // Check what's in the database
        if (typeof wmo_ajax !== 'undefined' && wmo_ajax.ajax_url) {
            $.post(wmo_ajax.ajax_url, {
                action: 'wmo_debug_settings',
                nonce: wmo_ajax.nonce
            }, function(response) {
                console.log('Current saved settings:', response);
            }).fail(function(xhr, status, error) {
                console.error('Debug settings request failed:', status, error);
                console.error('Response:', xhr.responseText);
            });
        } else {
            console.error('WMO: wmo_ajax object not available for debug request');
        }
        
        // Check what elements exist
        console.log('Color field elements:', $('.color-field'));
        console.log('WMO Color field elements:', $('.wmo-color-field'));
        
        // Initialize color pickers with debugging
        $('.color-field').each(function() {
            console.log('Initializing color picker for:', this);
            
            $(this).wpColorPicker({
                change: function(event, ui) {
                    console.log('Color changed');
                }
            });
        });
        
        // After initialization, let's force z-index on ALL picker elements
        setTimeout(function() {
            console.log('Applying z-index fix...');
            
            // Try multiple selectors to catch the elements
            var styles = 'z-index: 999999 !important; position: absolute !important;';
            
            $('.wp-picker-holder').attr('style', function(i, s) { 
                return (s || '') + styles; 
            });
            
            $('.iris-picker').attr('style', function(i, s) { 
                return (s || '') + styles; 
            });
            
            $('.wp-picker-container').css('position', 'relative');
            
            console.log('wp-picker-holder elements:', $('.wp-picker-holder'));
            console.log('iris-picker elements:', $('.iris-picker'));
        }, 1000);
        
        // Also try on any click in the color field area
        $(document).on('click', '.wp-color-result, .wp-color-result-text', function() {
            console.log('Color button clicked');
            
            setTimeout(function() {
                var $picker = $('.iris-picker:visible, .wp-picker-holder:visible');
                console.log('Visible picker elements:', $picker);
                
                $picker.each(function() {
                    $(this).attr('style', 'z-index: 999999 !important; position: absolute !important;');
                    console.log('Applied z-index to:', this);
                });
            }, 100);
        });
        
        // Initialize existing color picker functionality
        if ($.fn.wpColorPicker) {
            $('.wmo-color-field').wpColorPicker({
                change: function(event, ui) {
                    var $input = $(this);
                    var slug = $input.data('menu-slug');
                    var color = ui.color.toString();
                    var isSubmenu = $input.data('is-submenu') === true;

                    console.log('WMO: Color changed for', slug, 'to', color, 'Is submenu:', isSubmenu);

                    // CRITICAL: Update the actual input value so it gets submitted with the form
                    $input.val(color);
                    
                    // Also find and update the original input (WordPress creates a hidden clone)
                    var inputName = $input.attr('name');
                    if (inputName) {
                        $('input[name="' + inputName + '"]').val(color);
                    }
                    
                    // Force trigger change event to ensure all handlers are called
                    $input.trigger('change');

                    // Trigger a custom event that can be listened to in admin.js
                    $(document).trigger('wmoColorChanged', [slug, color, isSubmenu]);
                    
                    // LIVE PREVIEW: Apply color immediately to the WordPress admin menu
                    if (typeof window.wmoApplyColor === 'function') {
                        console.log('WMO: Calling window.wmoApplyColor for live preview');
                        window.wmoApplyColor(slug, color, isSubmenu, true);
                    } else if (typeof wmoApplyColor === 'function') {
                        console.log('WMO: Calling wmoApplyColor for live preview');
                        wmoApplyColor(slug, color, isSubmenu, true);
                    } else {
                        console.log('WMO: Using fallback wmoApplyColorDirect for live preview');
                        // Fallback: Apply color directly if wmoApplyColor function not available
                        wmoApplyColorDirect(slug, color);
                    }
                    
                    // AUTO-SAVE: Save the color automatically after a short delay
                    wmoAutoSaveColor(slug, color, $input);
                    
                    // AUTO-CLOSE: Close the color picker after a brief delay to show the selection
                    setTimeout(function() {
                        $input.wpColorPicker('close');
                    }, 300); // 300ms delay to let user see their selection
                },
                clear: function(event, ui) {
                    var $input = $(this);
                    var slug = $input.data('menu-slug');
                    var isSubmenu = $input.data('is-submenu') === true;
                    
                    console.log('WMO: Color cleared for', slug);
                    
                    // Clear the actual input value
                    $input.val('');
                    
                    // Also clear the original input
                    var inputName = $input.attr('name');
                    if (inputName) {
                        $('input[name="' + inputName + '"]').val('');
                    }
                    
                    // Trigger clear event
                    $(document).trigger('wmoColorCleared', [slug]);
                    
                    // LIVE PREVIEW: Clear color immediately from the WordPress admin menu
                    if (typeof window.wmoApplyColor === 'function') {
                        window.wmoApplyColor(slug, '', isSubmenu, true);
                    } else if (typeof wmoApplyColor === 'function') {
                        wmoApplyColor(slug, '', isSubmenu, true);
                    } else {
                        // Fallback: Clear color directly
                        wmoApplyColorDirect(slug, '');
                    }
                    
                    // AUTO-SAVE: Save the cleared color automatically
                    wmoAutoSaveColor(slug, '', $input);
                    
                    // AUTO-CLOSE: Close the color picker after clearing
                    setTimeout(function() {
                        $input.wpColorPicker('close');
                    }, 300); // 300ms delay for consistency
                },
                open: function(event, ui) {
                    // Force z-index when picker opens
                    setTimeout(function() {
                        $('.wp-picker-holder').css({
                            'z-index': '999999',
                            'position': 'absolute'
                        });
                        $('.iris-picker').css({
                            'z-index': '999999',
                            'position': 'absolute',
                            'background': '#fff',
                            'box-shadow': '0 5px 15px rgba(0,0,0,0.3)'
                        });
                        $('.iris-picker-inner').css({
                            'z-index': '999999',
                            'position': 'relative'
                        });
                    }, 10);
                }
            });
            
            // Initialize badge color pickers
            $('.wmo-badge-color-picker, .wmo-badge-bg-picker').wpColorPicker({
                change: function(event, ui) {
                    var $input = $(this);
                    var slug = $input.data('menu-slug');
                    var color = ui.color.toString();
                    
                    // Update the input value
                    $input.val(color);
                    
                    // Update live preview
                    wmoUpdateBadgePreview(slug);
                    
                    // Auto-save badge
                    wmoAutoSaveBadge(slug);
                    
                    // Auto-close
                    setTimeout(function() {
                        $input.wpColorPicker('close');
                    }, 300);
                }
            });
        } else {
            console.error('WMO: WordPress Color Picker not available');
        }
        
        // Debounced autosave function
        var autoSaveTimeouts = {};
        function wmoAutoSaveColor(slug, color, $input) {
            // Clear any existing timeout for this slug
            if (autoSaveTimeouts[slug]) {
                clearTimeout(autoSaveTimeouts[slug]);
            }
            
            // Show saving indicator
            wmoShowSavingIndicator($input, 'Saving...');
            
            // Set a new timeout to save after 500ms delay
            autoSaveTimeouts[slug] = setTimeout(function() {
                console.log('WMO: Auto-saving color for', slug, ':', color);
                console.log('WMO: Using action: wmo_save_color');
                console.log('WMO: Input element:', $input);
                console.log('WMO: Input name:', $input.attr('name'));
                console.log('WMO: Input value:', $input.val());
                
                $.ajax({
                    url: wmo_ajax.ajax_url,
                    method: 'POST',
                    data: {
                        action: 'wmo_save_color',
                        id: slug,  // Use 'id' to match PHP handler expectations
                        color: color,
                        nonce: wmo_ajax.nonce
                    },
                    success: function(response) {
                        console.log('WMO: Auto-save response:', response);
                        console.log('WMO: Response type:', typeof response);
                        if (typeof response === 'string') {
                            try {
                                response = JSON.parse(response);
                            } catch (e) {
                                console.error('WMO: Failed to parse response as JSON:', e);
                            }
                        }
                        
                        if (response.success) {
                            wmoShowSavingIndicator($input, 'Saved!', 'success');
                            console.log('WMO: Color auto-saved successfully');
                        } else {
                            wmoShowSavingIndicator($input, 'Error saving', 'error');
                            console.error('WMO: Auto-save failed:', response.data);
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.error('WMO: Auto-save AJAX error:', textStatus, errorThrown);
                        console.error('WMO: Response text:', jqXHR.responseText);
                        console.error('WMO: Status code:', jqXHR.status);
                        wmoShowSavingIndicator($input, 'Save failed', 'error');
                    }
                });
            }, 500); // 500ms delay for debouncing
        }
        
        // Function to show saving indicators
        function wmoShowSavingIndicator($input, message, type = 'info') {
            // Find or create indicator container
            var $container = $input.closest('.wp-picker-container');
            var $indicator = $container.find('.wmo-save-indicator');
            
            if ($indicator.length === 0) {
                $indicator = $('<span class="wmo-save-indicator"></span>');
                $container.append($indicator);
            }
            
            // Set the message and type
            $indicator.removeClass('wmo-saving wmo-success wmo-error').addClass('wmo-' + type).text(message).show();
            
            // Auto-hide after 2 seconds (except for saving state)
            if (type !== 'info') {
                setTimeout(function() {
                    $indicator.fadeOut();
                }, 2000);
            }
        }
        
        // Also add a global click handler to ensure z-index when any picker is clicked
        $(document).on('click', '.wp-color-result', function() {
            setTimeout(function() {
                $('.wp-picker-holder:visible').css({
                    'z-index': '999999',
                    'position': 'absolute'
                });
                $('.iris-picker:visible').css({
                    'z-index': '999999',
                    'position': 'absolute'
                });
            }, 50);
        });
        
        // Initialize inline color picker
        initInlineColorPicker();
        
        // Initialize badge functionality
        initBadgeFunctionality();
        
        // Initialize theme toggle functionality
        initThemeToggle();
        
        // Initialize typography functionality
        initTypographyFunctionality();
        
        // Initialize import/export functionality
        initImportExportFunctionality();
        
        // Initialize compact card functionality
        initCompactCardFunctionality();
        
        // Initialize icon system functionality
        initIconSystemFunctionality();
        
        // Menu search/filter functionality
        $('#wmo-menu-search').on('keyup', function() {
            var search = $(this).val().toLowerCase();
            
            if (search === '') {
                $('.wmo-color-group').show();
            } else {
                $('.wmo-color-group').each(function() {
                    var $group = $(this);
                    var text = $group.text().toLowerCase();
                    var matches = text.indexOf(search) > -1;
                    $group.toggle(matches);
                });
            }
            
            // Optional: Show count (remove if not wanted)
            var visible = $('.wmo-color-group:visible').length;
            var total = $('.wmo-color-group').length;
            if (search !== '') {
                console.log(`Showing ${visible} of ${total} menu groups`);
            }
        });
        
        // Debug function to check current color values
        window.wmoDebugColors = function() {
            console.log('=== WMO Color Debug ===');
            $('.wmo-color-field').each(function() {
                var $input = $(this);
                var slug = $input.data('menu-slug');
                var value = $input.val();
                var name = $input.attr('name');
                console.log('Field:', slug, 'Name:', name, 'Value:', value);
            });
            
            // Also check if WordPress Color Picker has different values
            $('.wp-color-picker').each(function() {
                var $input = $(this);
                var value = $input.val();
                var slug = $input.data('menu-slug');
                console.log('WP Color Picker:', slug, 'Value:', value);
            });
        };
    });
    
    // Initialize inline color picker when sortable is ready
    $(document).on('wmo_inline_ready', function(event, item) {
        console.log('WMO: Inline color picker ready for item:', item);
        initInlineColorPicker();
    });

    // Fallback function to apply colors directly if main wmoApplyColor function is not available
    function wmoApplyColorDirect(slug, color) {
        console.log('WMO: Applying color directly (fallback):', slug, color);
        
        // For icons, inject CSS to target pseudo-elements
        wmoInjectIconCSSFallback(slug, color);
        
        // Try multiple selector patterns to find the menu item
        var selectors = [
            '#menu-' + slug + ' > a',                    // Standard WordPress menu format
            '#toplevel_page_' + slug + ' > a',           // Plugin pages
            'li[id="menu-' + slug + '"] > a',           // Alternative format
            'li[class*="menu-' + slug + '"] > a',       // Class-based matching
            '#adminmenu li[id*="' + slug + '"] > a',    // More specific ID matching
            '#adminmenu a[href*="' + slug + '"]'        // Href-based matching
        ];
        
        var found = false;
        selectors.forEach(function(selector) {
            console.log('WMO: Trying selector:', selector);
            var elements = document.querySelectorAll(selector);
            console.log('WMO: Found elements:', elements.length);
            elements.forEach(function(element) {
                if (element) {
                    // Use !important to override server-side CSS
                    element.style.setProperty('color', color || '', 'important');
                    found = true;
                    console.log('WMO: Applied color to element via selector with !important:', selector, element);
                    
                    // Also apply to the menu icon if it exists - improved targeting
                    var iconSelectors = [
                        '.wp-menu-image:before',
                        '.wp-menu-image',
                        '.dashicons',
                        '.dashicons:before'
                    ];
                    
                    iconSelectors.forEach(function(iconSelector) {
                        var icons = element.querySelectorAll(iconSelector);
                        if (icons.length === 0) {
                            // Try finding icon in parent menu item
                            var parentLi = element.closest('li');
                            if (parentLi) {
                                icons = parentLi.querySelectorAll(iconSelector);
                            }
                        }
                        
                        icons.forEach(function(icon) {
                            if (icon) {
                                icon.style.setProperty('color', color || '', 'important');
                                console.log('WMO: Applied color to icon via selector:', iconSelector, icon);
                            }
                        });
                    });
                    
                    // Also target the parent li element's icon styles directly
                    var parentLi = element.closest('li');
                    if (parentLi) {
                        var directIcon = parentLi.querySelector('.wp-menu-image');
                        if (directIcon) {
                            directIcon.style.setProperty('color', color || '', 'important');
                            console.log('WMO: Applied color to direct icon with !important');
                        }
                    }
                }
            });
        });
        
        // If not found by ID, try text-based matching
        if (!found) {
            console.log('WMO: Trying text-based matching for:', slug);
            var menuLinks = document.querySelectorAll('#adminmenu > li > a');
            console.log('WMO: Found menu links:', menuLinks.length);
            menuLinks.forEach(function(link) {
                var linkText = link.textContent.trim().toLowerCase();
                var slugText = slug.replace(/-/g, ' ').toLowerCase();
                console.log('WMO: Comparing "' + linkText + '" with "' + slugText + '"');
                if (linkText === slugText || linkText.includes(slugText)) {
                    // Use !important to override server-side CSS
                    link.style.setProperty('color', color || '', 'important');
                    console.log('WMO: Applied color to element via text matching with !important:', linkText, link);
                    found = true;
                    
                    // Also apply to the menu icon - improved targeting
                    var iconSelectors = [
                        '.wp-menu-image:before',
                        '.wp-menu-image',
                        '.dashicons',
                        '.dashicons:before'
                    ];
                    
                    iconSelectors.forEach(function(iconSelector) {
                        var icons = link.querySelectorAll(iconSelector);
                        if (icons.length === 0) {
                            // Try finding icon in parent menu item
                            var parentLi = link.closest('li');
                            if (parentLi) {
                                icons = parentLi.querySelectorAll(iconSelector);
                            }
                        }
                        
                        icons.forEach(function(icon) {
                            if (icon) {
                                icon.style.setProperty('color', color || '', 'important');
                                console.log('WMO: Applied color to icon via text matching:', iconSelector, icon);
                            }
                        });
                    });
                    
                    // Also target the parent li element's icon styles directly
                    var parentLi = link.closest('li');
                    if (parentLi) {
                        var directIcon = parentLi.querySelector('.wp-menu-image');
                        if (directIcon) {
                            directIcon.style.setProperty('color', color || '', 'important');
                            console.log('WMO: Applied color to direct icon via text matching');
                        }
                    }
                }
            });
        }
        
        if (!found) {
            console.log('WMO: Could not find menu item for slug:', slug);
            // Let's also log what menu items are actually available
            var allMenuItems = document.querySelectorAll('#adminmenu > li');
            console.log('WMO: Available menu items:');
            allMenuItems.forEach(function(item, index) {
                if (index < 10) { // Only log first 10 to avoid spam
                    console.log('  ' + index + ':', item.id, item.className, item.textContent.trim().substring(0, 30));
                }
            });
        }
    }

    // Fallback CSS injection function for icons
    function wmoInjectIconCSSFallback(slug, color) {
        console.log('WMO: Injecting icon CSS (fallback) for', slug, 'with color', color);
        
        // Remove any existing preview CSS for this slug
        var existingStyle = document.getElementById('wmo-preview-fallback-' + slug);
        if (existingStyle) {
            existingStyle.remove();
        }
        
        if (color) {
            // Create new style element
            var style = document.createElement('style');
            style.id = 'wmo-preview-fallback-' + slug;
            style.type = 'text/css';
            
            // Generate CSS for various menu icon selectors
            var css = '';
            var selectors = [
                '#menu-' + slug + ' .wp-menu-image:before',
                '#menu-' + slug + ' .dashicons:before',
                '#toplevel_page_' + slug + ' .wp-menu-image:before',
                '#toplevel_page_' + slug + ' .dashicons:before',
                '#adminmenu li[id*="' + slug + '"] .wp-menu-image:before',
                '#adminmenu li[id*="' + slug + '"] .dashicons:before',
                '#menu-' + slug + ' .wp-menu-image',
                '#menu-' + slug + ' .dashicons',
                '#toplevel_page_' + slug + ' .wp-menu-image',
                '#toplevel_page_' + slug + ' .dashicons',
                '#adminmenu li[id*="' + slug + '"] .wp-menu-image',
                '#adminmenu li[id*="' + slug + '"] .dashicons'
            ];
            
            selectors.forEach(function(selector) {
                css += selector + ' { color: ' + color + ' !important; }\n';
            });
            
            style.innerHTML = css;
            document.head.appendChild(style);
            
            console.log('WMO: Injected fallback icon CSS:', css);
        }
    }

    // Badge functionality initialization
    function initBadgeFunctionality() {
        console.log('WMO: Initializing badge functionality');
        
        // Handle badge enable/disable toggle
        $(document).on('change', '.wmo-badge-enable', function() {
            var $checkbox = $(this);
            var slug = $checkbox.data('menu-slug');
            var enabled = $checkbox.is(':checked');
            var $controls = $checkbox.closest('.wmo-badge-wrapper').find('.wmo-badge-controls');
            
            console.log('WMO: Badge toggle for', slug, 'enabled:', enabled);
            
            if (enabled) {
                $controls.show();
            } else {
                $controls.hide();
                // Remove badge from menu when disabled
                wmoRemoveBadgeFromMenu(slug);
            }
            
            // Auto-save the change
            wmoAutoSaveBadge(slug);
        });
        
        // Handle badge text changes
        $(document).on('input', '.wmo-badge-text', function() {
            var $input = $(this);
            var slug = $input.data('menu-slug');
            
            // Update preview
            wmoUpdateBadgePreview(slug);
            
            // Debounced auto-save
            clearTimeout(window.wmoBadgeTextTimeout);
            window.wmoBadgeTextTimeout = setTimeout(function() {
                wmoAutoSaveBadge(slug);
            }, 500);
        });
        
        // Apply existing badges on page load
        setTimeout(function() {
            $('.wmo-badge-enable:checked').each(function() {
                var slug = $(this).data('menu-slug');
                wmoApplyBadgeToMenu(slug);
            });
        }, 1000);
    }
    
    // Update badge preview
    function wmoUpdateBadgePreview(slug) {
        var $wrapper = $('.wmo-badge-wrapper').filter(function() {
            return $(this).find('[data-menu-slug="' + slug + '"]').length > 0;
        });
        
        var $preview = $wrapper.find('.wmo-badge-sample[data-menu-slug="' + slug + '"]');
        var text = $wrapper.find('.wmo-badge-text[data-menu-slug="' + slug + '"]').val() || 'Preview';
        var textColor = $wrapper.find('.wmo-badge-color-picker[data-menu-slug="' + slug + '"]').val() || '#ffffff';
        var bgColor = $wrapper.find('.wmo-badge-bg-picker[data-menu-slug="' + slug + '"]').val() || '#0073aa';
        
        $preview.text(text).css({
            'color': textColor,
            'background-color': bgColor
        });
        
        // Also update the actual menu badge if enabled
        var enabled = $wrapper.find('.wmo-badge-enable[data-menu-slug="' + slug + '"]').is(':checked');
        if (enabled) {
            wmoApplyBadgeToMenu(slug);
        }
    }
    
    // Apply badge to WordPress menu
    function wmoApplyBadgeToMenu(slug) {
        var $wrapper = $('.wmo-badge-wrapper').filter(function() {
            return $(this).find('[data-menu-slug="' + slug + '"]').length > 0;
        });
        
        var enabled = $wrapper.find('.wmo-badge-enable[data-menu-slug="' + slug + '"]').is(':checked');
        if (!enabled) {
            wmoRemoveBadgeFromMenu(slug);
            return;
        }
        
        var text = $wrapper.find('.wmo-badge-text[data-menu-slug="' + slug + '"]').val();
        var textColor = $wrapper.find('.wmo-badge-color-picker[data-menu-slug="' + slug + '"]').val() || '#ffffff';
        var bgColor = $wrapper.find('.wmo-badge-bg-picker[data-menu-slug="' + slug + '"]').val() || '#0073aa';
        
        if (!text) return;
        
        // Find menu items to apply badge to
        var selectors = [
            '#menu-' + slug + ' > a .wp-menu-name',
            '#toplevel_page_' + slug + ' > a .wp-menu-name',
            '#adminmenu li[id*="' + slug + '"] > a .wp-menu-name'
        ];
        
        var found = false;
        selectors.forEach(function(selector) {
            var $menuItems = $(selector);
            if ($menuItems.length > 0) {
                $menuItems.each(function() {
                    var $menuName = $(this);
                    // Remove existing badge
                    $menuName.find('.wmo-menu-badge').remove();
                    // Add new badge
                    var $badge = $('<span class="wmo-menu-badge"></span>')
                        .text(text)
                        .css({
                            'color': textColor,
                            'background-color': bgColor
                        });
                    $menuName.append($badge);
                    found = true;
                });
            }
        });
        
        // Fallback: try text-based matching
        if (!found) {
            $('#adminmenu > li > a').each(function() {
                var $link = $(this);
                var linkText = $link.text().trim().toLowerCase();
                var slugText = slug.replace(/-/g, ' ').toLowerCase();
                
                if (linkText.includes(slugText)) {
                    var $menuName = $link.find('.wp-menu-name');
                    if ($menuName.length === 0) {
                        $menuName = $link;
                    }
                    
                    // Remove existing badge
                    $menuName.find('.wmo-menu-badge').remove();
                    // Add new badge
                    var $badge = $('<span class="wmo-menu-badge"></span>')
                        .text(text)
                        .css({
                            'color': textColor,
                            'background-color': bgColor
                        });
                    $menuName.append($badge);
                }
            });
        }
    }
    
    // Remove badge from WordPress menu
    function wmoRemoveBadgeFromMenu(slug) {
        var selectors = [
            '#menu-' + slug,
            '#toplevel_page_' + slug,
            '#adminmenu li[id*="' + slug + '"]'
        ];
        
        selectors.forEach(function(selector) {
            $(selector).find('.wmo-menu-badge').remove();
        });
    }
    
    // Auto-save badge data
    var badgeAutoSaveTimeouts = {};
    function wmoAutoSaveBadge(slug) {
        // Clear any existing timeout for this slug
        if (badgeAutoSaveTimeouts[slug]) {
            clearTimeout(badgeAutoSaveTimeouts[slug]);
        }
        
        // Set a new timeout to save after 500ms delay
        badgeAutoSaveTimeouts[slug] = setTimeout(function() {
            console.log('WMO: Auto-saving badge for', slug);
            
            var $wrapper = $('.wmo-badge-wrapper').filter(function() {
                return $(this).find('[data-menu-slug="' + slug + '"]').length > 0;
            });
            
            var enabled = $wrapper.find('.wmo-badge-enable[data-menu-slug="' + slug + '"]').is(':checked');
            var text = $wrapper.find('.wmo-badge-text[data-menu-slug="' + slug + '"]').val();
            var textColor = $wrapper.find('.wmo-badge-color-picker[data-menu-slug="' + slug + '"]').val();
            var bgColor = $wrapper.find('.wmo-badge-bg-picker[data-menu-slug="' + slug + '"]').val();
            
            console.log('WMO: Badge data to save:', {
                slug: slug,
                enabled: enabled,
                text: text,
                textColor: textColor,
                bgColor: bgColor
            });
            
            $.ajax({
                url: wmo_ajax.ajax_url,
                method: 'POST',
                data: {
                    action: 'wmo_save_badge',
                    slug: slug,
                    enabled: enabled ? 1 : 0,
                    text: text,
                    color: textColor,
                    background: bgColor,
                    nonce: wmo_ajax.nonce
                },
                success: function(response) {
                    console.log('WMO: Badge auto-save response:', response);
                    if (response.success) {
                        console.log('WMO: Badge auto-saved successfully');
                    } else {
                        console.error('WMO: Badge auto-save failed:', response.data);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.error('WMO: Badge auto-save AJAX error:', textStatus, errorThrown);
                    console.error('WMO: Badge save response text:', jqXHR.responseText);
                }
            });
        }, 500); // 500ms delay for debouncing
    }

    // Theme toggle functionality
    function initThemeToggle() {
        console.log('WMO: Initializing theme toggle functionality');
        
        var $themeToggle = $('#wmo-dark-mode-toggle');
        
        // Load saved theme preference
        var isDarkMode = localStorage.getItem('wmo_dark_mode') === 'true';
        
        // Apply saved theme on page load
        if (isDarkMode) {
            $('body').addClass('wmo-dark-theme');
            $themeToggle.prop('checked', true);
            console.log('WMO: Applied dark theme from localStorage');
        }
        
        // Handle theme toggle
        $themeToggle.on('change', function() {
            var isChecked = $(this).is(':checked');
            
            console.log('WMO: Theme toggle changed to:', isChecked ? 'dark' : 'light');
            
            if (isChecked) {
                // Switch to dark mode
                $('body').addClass('wmo-dark-theme');
                localStorage.setItem('wmo_dark_mode', 'true');
                
                // Show feedback
                wmoShowThemeNotification('Dark mode enabled', 'dark');
            } else {
                // Switch to light mode
                $('body').removeClass('wmo-dark-theme');
                localStorage.setItem('wmo_dark_mode', 'false');
                
                // Show feedback
                wmoShowThemeNotification('Light mode enabled', 'light');
            }
            
            // Auto-save theme preference
            wmoAutoSaveTheme(isChecked);
        });
    }
    
    // Show theme change notification
    function wmoShowThemeNotification(message, theme) {
        // Remove any existing notification
        $('.wmo-theme-notification').remove();
        
        var $notification = $('<div class="wmo-theme-notification wmo-theme-' + theme + '">' + message + '</div>');
        
        $('body').append($notification);
        
        // Show with animation
        setTimeout(function() {
            $notification.addClass('show');
        }, 10);
        
        // Hide after 3 seconds
        setTimeout(function() {
            $notification.removeClass('show');
            setTimeout(function() {
                $notification.remove();
            }, 300);
        }, 3000);
    }
    
    // Auto-save theme preference
    var themeAutoSaveTimeout;
    function wmoAutoSaveTheme(isDarkMode) {
        // Clear any existing timeout
        if (themeAutoSaveTimeout) {
            clearTimeout(themeAutoSaveTimeout);
        }
        
        // Set a new timeout to save after 500ms delay
        themeAutoSaveTimeout = setTimeout(function() {
            console.log('WMO: Auto-saving theme preference:', isDarkMode ? 'dark' : 'light');
            
            $.ajax({
                url: wmo_ajax.ajax_url,
                method: 'POST',
                data: {
                    action: 'wmo_save_theme',
                    dark_mode: isDarkMode ? 1 : 0,
                    nonce: wmo_ajax.nonce
                },
                success: function(response) {
                    console.log('WMO: Theme auto-save response:', response);
                    if (response.success) {
                        console.log('WMO: Theme preference auto-saved successfully');
                    } else {
                        console.error('WMO: Theme auto-save failed:', response.data);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.error('WMO: Theme auto-save AJAX error:', textStatus, errorThrown);
                }
            });
        }, 500); // 500ms delay for debouncing
    }

    // Typography functionality initialization
    function initTypographyFunctionality() {
        console.log('WMO: Initializing typography functionality');
        
        // Handle typography enable/disable toggle
        $(document).on('change', '.wmo-typography-enable', function() {
            var $checkbox = $(this);
            var slug = $checkbox.data('menu-slug');
            var enabled = $checkbox.is(':checked');
            var $controls = $checkbox.closest('.wmo-typography-wrapper').find('.wmo-typography-controls');
            
            console.log('WMO: Typography toggle for', slug, 'enabled:', enabled);
            
            if (enabled) {
                $controls.show();
            } else {
                $controls.hide();
                // Remove typography from menu when disabled
                wmoRemoveTypographyFromMenu(slug);
            }
            
            // Auto-save the change
            wmoAutoSaveTypography(slug);
        });
        
        // Handle typography dropdown changes
        $(document).on('change', '.wmo-typography-family, .wmo-typography-size, .wmo-typography-weight', function() {
            var $select = $(this);
            var slug = $select.data('menu-slug');
            
            console.log('WMO: Typography changed for', slug);
            
            // Update preview
            wmoUpdateTypographyPreview(slug);
            
            // Apply to actual menu immediately (live preview)
            wmoApplyTypographyToMenu(slug);
            
            // Debounced auto-save
            clearTimeout(window.wmoTypographyTimeout);
            window.wmoTypographyTimeout = setTimeout(function() {
                wmoAutoSaveTypography(slug);
            }, 500);
        });
        
        // Apply existing typography on page load
        setTimeout(function() {
            $('.wmo-typography-enable:checked').each(function() {
                var slug = $(this).data('menu-slug');
                wmoApplyTypographyToMenu(slug);
            });
        }, 1000);
    }
    
    // Update typography preview
    function wmoUpdateTypographyPreview(slug) {
        var $wrapper = $('.wmo-typography-wrapper').filter(function() {
            return $(this).find('[data-menu-slug="' + slug + '"]').length > 0;
        });
        
        var $preview = $wrapper.find('.wmo-typography-sample[data-menu-slug="' + slug + '"]');
        var fontFamily = $wrapper.find('.wmo-typography-family[data-menu-slug="' + slug + '"]').val();
        var fontSize = $wrapper.find('.wmo-typography-size[data-menu-slug="' + slug + '"]').val();
        var fontWeight = $wrapper.find('.wmo-typography-weight[data-menu-slug="' + slug + '"]').val();
        
        // Apply typography styles to preview
        var styles = {};
        if (fontFamily) styles['font-family'] = fontFamily;
        if (fontSize) styles['font-size'] = fontSize;
        if (fontWeight) styles['font-weight'] = fontWeight;
        
        $preview.css(styles);
        
        console.log('WMO: Updated typography preview for', slug, 'with styles:', styles);
    }
    
    // Apply typography to WordPress menu
    function wmoApplyTypographyToMenu(slug) {
        var $wrapper = $('.wmo-typography-wrapper').filter(function() {
            return $(this).find('[data-menu-slug="' + slug + '"]').length > 0;
        });
        
        var enabled = $wrapper.find('.wmo-typography-enable[data-menu-slug="' + slug + '"]').is(':checked');
        if (!enabled) {
            wmoRemoveTypographyFromMenu(slug);
            return;
        }
        
        var fontFamily = $wrapper.find('.wmo-typography-family[data-menu-slug="' + slug + '"]').val();
        var fontSize = $wrapper.find('.wmo-typography-size[data-menu-slug="' + slug + '"]').val();
        var fontWeight = $wrapper.find('.wmo-typography-weight[data-menu-slug="' + slug + '"]').val();
        
        console.log('WMO: Applying typography to menu for', slug, '- Family:', fontFamily, 'Size:', fontSize, 'Weight:', fontWeight);
        
        // Find menu items to apply typography to
        var selectors = [
            '#menu-' + slug + ' > a',                    // Standard WordPress menu format
            '#toplevel_page_' + slug + ' > a',           // Plugin pages
            'li[id="menu-' + slug + '"] > a',           // Alternative format
            'li[class*="menu-' + slug + '"] > a',       // Class-based matching
            '#adminmenu li[id*="' + slug + '"] > a',    // More specific ID matching
            '#adminmenu a[href*="' + slug + '"]'        // Href-based matching
        ];
        
        var found = false;
        selectors.forEach(function(selector) {
            var elements = document.querySelectorAll(selector);
            elements.forEach(function(element) {
                if (element) {
                    // Apply typography styles with !important for higher priority
                    if (fontFamily) element.style.setProperty('font-family', fontFamily, 'important');
                    if (fontSize) element.style.setProperty('font-size', fontSize, 'important');
                    if (fontWeight) element.style.setProperty('font-weight', fontWeight, 'important');
                    
                    found = true;
                    console.log('WMO: Applied typography to element:', element);
                }
            });
        });
        
        // Fallback: try text-based matching
        if (!found) {
            $('#adminmenu > li > a').each(function() {
                var $link = $(this);
                var linkText = $link.text().trim().toLowerCase();
                var slugText = slug.replace(/-/g, ' ').toLowerCase();
                
                if (linkText.includes(slugText)) {
                    var element = this;
                    if (fontFamily) element.style.setProperty('font-family', fontFamily, 'important');
                    if (fontSize) element.style.setProperty('font-size', fontSize, 'important');
                    if (fontWeight) element.style.setProperty('font-weight', fontWeight, 'important');
                    
                    console.log('WMO: Applied typography via text matching to:', element);
                }
            });
        }
    }
    
    // Remove typography from WordPress menu
    function wmoRemoveTypographyFromMenu(slug) {
        console.log('WMO: Removing typography from menu for', slug);
        
        var selectors = [
            '#menu-' + slug + ' > a',
            '#toplevel_page_' + slug + ' > a',
            'li[id="menu-' + slug + '"] > a',
            '#adminmenu li[id*="' + slug + '"] > a'
        ];
        
        selectors.forEach(function(selector) {
            var elements = document.querySelectorAll(selector);
            elements.forEach(function(element) {
                if (element) {
                    // Remove typography styles
                    element.style.removeProperty('font-family');
                    element.style.removeProperty('font-size');
                    element.style.removeProperty('font-weight');
                }
            });
        });
    }
    
    // Auto-save typography data
    var typographyAutoSaveTimeouts = {};
    function wmoAutoSaveTypography(slug) {
        // Clear any existing timeout for this slug
        if (typographyAutoSaveTimeouts[slug]) {
            clearTimeout(typographyAutoSaveTimeouts[slug]);
        }
        
        // Set a new timeout to save after 500ms delay
        typographyAutoSaveTimeouts[slug] = setTimeout(function() {
            console.log('WMO: Auto-saving typography for', slug);
            
            var $wrapper = $('.wmo-typography-wrapper').filter(function() {
                return $(this).find('[data-menu-slug="' + slug + '"]').length > 0;
            });
            
            var enabled = $wrapper.find('.wmo-typography-enable[data-menu-slug="' + slug + '"]').is(':checked');
            var fontFamily = $wrapper.find('.wmo-typography-family[data-menu-slug="' + slug + '"]').val();
            var fontSize = $wrapper.find('.wmo-typography-size[data-menu-slug="' + slug + '"]').val();
            var fontWeight = $wrapper.find('.wmo-typography-weight[data-menu-slug="' + slug + '"]').val();
            
            console.log('WMO: Typography data to save:', {
                slug: slug,
                enabled: enabled,
                fontFamily: fontFamily,
                fontSize: fontSize,
                fontWeight: fontWeight
            });
            
            $.ajax({
                url: wmo_ajax.ajax_url,
                method: 'POST',
                data: {
                    action: 'wmo_save_typography',
                    slug: slug,
                    enabled: enabled ? 1 : 0,
                    font_family: fontFamily,
                    font_size: fontSize,
                    font_weight: fontWeight,
                    nonce: wmo_ajax.nonce
                },
                success: function(response) {
                    console.log('WMO: Typography auto-save response:', response);
                    if (response.success) {
                        console.log('WMO: Typography auto-saved successfully');
                    } else {
                        console.error('WMO: Typography auto-save failed:', response.data);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.error('WMO: Typography auto-save AJAX error:', textStatus, errorThrown);
                    console.error('WMO: Typography save response text:', jqXHR.responseText);
                }
            });
        }, 500); // 500ms delay for debouncing
    }

    // Import/Export functionality initialization
    function initImportExportFunctionality() {
        console.log('WMO: Initializing import/export functionality');

        // Export button handler
        $('#wmo-export-btn').on('click', function() {
            console.log('WMO: Export button clicked');
            
            var exportOptions = {
                colors: $('#wmo-export-colors').is(':checked'),
                typography: $('#wmo-export-typography').is(':checked'),
                badges: $('#wmo-export-badges').is(':checked'),
                theme: $('#wmo-export-theme').is(':checked')
            };
            
            console.log('WMO: Export options:', exportOptions);
            
            $.ajax({
                url: wmo_ajax.ajax_url,
                method: 'POST',
                data: {
                    action: 'wmo_export_configuration',
                    colors: exportOptions.colors,
                    typography: exportOptions.typography,
                    badges: exportOptions.badges,
                    theme: exportOptions.theme,
                    nonce: wmo_ajax.nonce
                },
                success: function(response) {
                    console.log('WMO: Export response:', response);
                    if (response.success) {
                        // Create and download file
                        var jsonString = JSON.stringify(response.data.data, null, 2);
                        var blob = new Blob([jsonString], { type: 'application/json' });
                        var url = URL.createObjectURL(blob);
                        
                        var a = document.createElement('a');
                        a.href = url;
                        a.download = response.data.filename;
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        URL.revokeObjectURL(url);
                        
                        wmoShowImportExportNotification('Configuration exported successfully!', 'success');
                    } else {
                        wmoShowImportExportNotification('Export failed: ' + (response.data || 'Unknown error'), 'error');
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.error('WMO: Export AJAX error:', textStatus, errorThrown);
                    wmoShowImportExportNotification('Export failed: Network error', 'error');
                }
            });
        });

        // File input handler
        $('#wmo-import-file').on('change', function() {
            var file = this.files[0];
            if (file) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#wmo-import-textarea').val(e.target.result);
                    wmoCheckImportData();
                };
                reader.readAsText(file);
            }
        });

        // Textarea input handler
        $('#wmo-import-textarea').on('input', function() {
            wmoCheckImportData();
        });

        // Preview import button handler
        $('#wmo-preview-import-btn').on('click', function() {
            var importData = $('#wmo-import-textarea').val();
            var importMode = $('input[name="wmo-import-mode"]:checked').val();
            
            if (!importData.trim()) {
                wmoShowImportExportNotification('Please provide import data', 'error');
                return;
            }
            
            console.log('WMO: Preview import clicked');
            
            $.ajax({
                url: wmo_ajax.ajax_url,
                method: 'POST',
                data: {
                    action: 'wmo_preview_import',
                    import_data: importData,
                    import_mode: importMode,
                    nonce: wmo_ajax.nonce
                },
                success: function(response) {
                    console.log('WMO: Preview response:', response);
                    if (response.success) {
                        wmoShowImportPreview(response.data);
                    } else {
                        wmoShowImportExportNotification('Preview failed: ' + (response.data || 'Unknown error'), 'error');
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.error('WMO: Preview AJAX error:', textStatus, errorThrown);
                    wmoShowImportExportNotification('Preview failed: Network error', 'error');
                }
            });
        });

        // Import button handler
        $('#wmo-import-btn').on('click', function() {
            var importData = $('#wmo-import-textarea').val();
            var importMode = $('input[name="wmo-import-mode"]:checked').val();
            
            if (!importData.trim()) {
                wmoShowImportExportNotification('Please provide import data', 'error');
                return;
            }
            
            console.log('WMO: Import button clicked');
            
            $.ajax({
                url: wmo_ajax.ajax_url,
                method: 'POST',
                data: {
                    action: 'wmo_import_configuration',
                    import_data: importData,
                    import_mode: importMode,
                    nonce: wmo_ajax.nonce
                },
                success: function(response) {
                    console.log('WMO: Import response:', response);
                    if (response.success) {
                        wmoShowImportExportNotification('Configuration imported successfully! Refreshing page...', 'success');
                        // Refresh page after 2 seconds to show changes
                        setTimeout(function() {
                            window.location.reload();
                        }, 2000);
                    } else {
                        wmoShowImportExportNotification('Import failed: ' + (response.data || 'Unknown error'), 'error');
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.error('WMO: Import AJAX error:', textStatus, errorThrown);
                    wmoShowImportExportNotification('Import failed: Network error', 'error');
                }
            });
        });

        // Confirm import button (from modal)
        $('#wmo-confirm-import-btn').on('click', function() {
            $('#wmo-import-preview-modal').hide();
            $('#wmo-import-btn').click();
        });

        // Modal close handlers
        $('.wmo-modal-close').on('click', function() {
            $('#wmo-import-preview-modal').hide();
        });

        // Close modal when clicking outside
        $('#wmo-import-preview-modal').on('click', function(e) {
            if (e.target === this) {
                $(this).hide();
            }
        });
    }

    // Check import data and enable/disable buttons
    function wmoCheckImportData() {
        var importData = $('#wmo-import-textarea').val();
        var hasData = importData.trim().length > 0;
        
        $('#wmo-preview-import-btn, #wmo-import-btn').prop('disabled', !hasData);
        
        if (hasData) {
            try {
                JSON.parse(importData);
                // Valid JSON
                $('#wmo-preview-import-btn, #wmo-import-btn').removeClass('button-secondary').addClass('button-primary');
            } catch (e) {
                // Invalid JSON
                $('#wmo-preview-import-btn, #wmo-import-btn').removeClass('button-primary').addClass('button-secondary');
            }
        }
    }

    // Show import preview modal
    function wmoShowImportPreview(data) {
        var previewHtml = '<div class="wmo-import-source-info">';
        previewHtml += '<p><strong>Source Information:</strong></p>';
        previewHtml += '<ul>';
        previewHtml += '<li>Version: ' + (data.source_info.version || 'Unknown') + '</li>';
        previewHtml += '<li>Export Date: ' + (data.source_info.export_date || 'Unknown') + '</li>';
        previewHtml += '<li>Site URL: ' + (data.source_info.site_url || 'Unknown') + '</li>';
        previewHtml += '</ul>';
        previewHtml += '</div>';
        
        if (Object.keys(data.preview).length > 0) {
            previewHtml += '<div class="wmo-import-changes">';
            previewHtml += '<p><strong>Changes to be made:</strong></p>';
            
            $.each(data.preview, function(type, changes) {
                previewHtml += '<h4>' + type.charAt(0).toUpperCase() + type.slice(1) + '</h4>';
                previewHtml += '<ul>';
                $.each(changes, function(index, change) {
                    previewHtml += '<li>' + change + '</li>';
                });
                previewHtml += '</ul>';
            });
            previewHtml += '</div>';
        } else {
            previewHtml += '<p><em>No changes will be made with the current settings.</em></p>';
        }
        
        $('#wmo-preview-content').html(previewHtml);
        $('#wmo-import-preview-modal').show();
    }

    // Show import/export notification
    function wmoShowImportExportNotification(message, type) {
        // Remove any existing notification
        $('.wmo-import-export-notification').remove();
        
        var $notification = $('<div class="wmo-import-export-notification wmo-notification-' + type + '">' + message + '</div>');
        
        // Add styles
        $notification.css({
            'position': 'fixed',
            'top': '32px',
            'right': '20px',
            'padding': '12px 20px',
            'border-radius': '6px',
            'font-weight': '500',
            'font-size': '14px',
            'z-index': '999999',
            'opacity': '0',
            'transform': 'translateY(-20px)',
            'transition': 'all 0.3s ease',
            'box-shadow': '0 4px 12px rgba(0,0,0,0.15)',
            'max-width': '400px'
        });
        
        if (type === 'success') {
            $notification.css({
                'background': '#27ae60',
                'color': 'white',
                'border-left': '4px solid #229954'
            });
        } else {
            $notification.css({
                'background': '#e74c3c',
                'color': 'white',
                'border-left': '4px solid #c0392b'
            });
        }
        
        $('body').append($notification);
        
        // Show with animation
        setTimeout(function() {
            $notification.css({
                'opacity': '1',
                'transform': 'translateY(0)'
            });
        }, 10);
        
        // Hide after 4 seconds
        setTimeout(function() {
            $notification.css({
                'opacity': '0',
                'transform': 'translateY(-20px)'
            });
            setTimeout(function() {
                $notification.remove();
            }, 300);
        }, 4000);
    }

    // Menu Templates functionality initialization
    function initTemplatesFunctionality() {
        console.log('WMO: Initializing templates functionality');
        wmoLoadTemplates('all');
        $('#wmo-template-category').on('change', function() {
            wmoLoadTemplates($(this).val());
        });
        $('#wmo-save-template-btn').on('click', wmoShowSaveTemplateModal);
        $('#wmo-save-template-confirm-btn').on('click', wmoSaveTemplate);
        $(document).on('click', '#wmo-apply-template-btn', function() {
            wmoApplyTemplate($(this).data('template-id'));
        });
    }

    function wmoLoadTemplates(category) {
        $('#wmo-templates-gallery').html('<div class="wmo-templates-loading"><span class="dashicons dashicons-update-alt wmo-spin"></span> Loading templates...</div>');
        $.ajax({
            url: wmo_ajax.ajax_url,
            method: 'POST',
            data: { action: 'wmo_load_templates', category: category, nonce: wmo_ajax.nonce },
            success: function(response) {
                if (response.success) wmoRenderTemplates(response.data.templates);
            }
        });
    }

    function wmoRenderTemplates(templates) {
        var html = '<div class="wmo-templates-grid">';
        templates.forEach(function(template) {
            html += '<div class="wmo-template-card" data-template-id="' + template.id + '">';
            html += '<h4>' + template.name + '</h4>';
            html += '<div class="wmo-template-description">' + template.description + '</div>';
            
            // Add color preview bar based on template name
            var templateName = template.name.toLowerCase();
            var colors = [];
            
            if (templateName.includes('default')) {
                colors = ['#23282d', '#0073aa', '#ffffff', '#f1f1f1'];
            } else if (templateName.includes('minimal')) {
                colors = ['#2271b1', '#72aee6', '#ffffff', '#f0f0f1'];
            } else if (templateName.includes('content') || templateName.includes('focused')) {
                colors = ['#d63638', '#ff8c00', '#0073aa', '#00a32a'];
            } else if (templateName.includes('dark')) {
                colors = ['#1e1e1e', '#2d2d2d', '#646464', '#00d4ff'];
            } else if (templateName.includes('classic')) {
                colors = ['#23282d', '#0073aa', '#00a0d2', '#0085ba'];
            } else if (templateName.includes('developer')) {
                colors = ['#000000', '#00ff00', '#008000', '#333333'];
            } else if (templateName.includes('agency')) {
                colors = ['#6c5ce7', '#a29bfe', '#fd79a8', '#fdcb6e'];
            } else if (templateName.includes('ecommerce') || templateName.includes('commerce')) {
                colors = ['#96588a', '#c9356c', '#f36e5d', '#fbb034'];
            } else if (templateName.includes('blogger')) {
                colors = ['#ffeaa7', '#dfe6e9', '#fd79a8', '#74b9ff'];
            } else {
                // Default color preview for other templates
                colors = ['#0073aa', '#72aee6', '#ffffff', '#f0f0f1'];
            }
            
            // Create color preview HTML
            html += '<div class="template-color-preview" style="display: flex; gap: 2px; margin: 10px 0; height: 20px;">';
            colors.forEach(function(color) {
                html += '<span style="background: ' + color + '; flex: 1;"></span>';
            });
            html += '</div>';
            
            html += '<div class="wmo-template-actions">';
            html += '<button class="wmo-apply-template wmo-primary" data-template-id="' + template.id + '">Apply</button>';
            html += '</div></div>';
        });
        html += '</div>';
        $('#wmo-templates-gallery').html(html);
    }

    function wmoShowSaveTemplateModal() { $('#wmo-save-template-modal').show(); }
    function wmoSaveTemplate() { /* Implementation */ }
    function wmoApplyTemplate(templateId) {
        $.ajax({
            url: wmo_ajax.ajax_url,
            method: 'POST',
            data: { action: 'wmo_apply_template', template_id: templateId, nonce: wmo_ajax.nonce },
            success: function(response) {
                if (response.success) window.location.reload();
            }
        });
    }

    // Compact card functionality initialization
    function initCompactCardFunctionality() {
        console.log('WMO: Initializing compact card functionality');
        
        // Handle expand/collapse toggle clicks - simplified approach
        $(document).on('click', '.wmo-expand-toggle', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('WMO: Expand toggle clicked');
            
            var $wrapper = $(this).closest('.wmo-menu-item-wrapper');
            var $content = $wrapper.find('.wmo-expanded-content');
            var $icon = $(this).find('.dashicons');
            
            console.log('WMO: Found wrapper:', $wrapper.length, 'Found content:', $content.length);
            console.log('WMO: Current wrapper classes:', $wrapper.attr('class'));
            console.log('WMO: Current content display:', $content.css('display'));
            
            if ($wrapper.hasClass('expanded')) {
                // Collapse
                console.log('WMO: Collapsing...');
                $wrapper.removeClass('expanded');
                $content.hide();
                $icon.removeClass('dashicons-arrow-up-alt2').addClass('dashicons-arrow-down-alt2');
                console.log('WMO: Collapsed menu item');
            } else {
                // Expand
                console.log('WMO: Expanding...');
                $wrapper.addClass('expanded');
                $content.show();
                $icon.removeClass('dashicons-arrow-down-alt2').addClass('dashicons-arrow-up-alt2');
                console.log('WMO: Expanded menu item');
            }
        });
        
        // Handle compact card header clicks
        $(document).on('click', '.wmo-menu-header', function(e) {
            // Don't trigger if clicking on color picker or other interactive elements
            if ($(e.target).closest('.wmo-color-picker-wrapper, .wmo-expand-toggle').length > 0) {
                return;
            }
            
            var $wrapper = $(this).closest('.wmo-menu-item-wrapper');
            var $content = $wrapper.find('.wmo-expanded-content');
            var $toggle = $wrapper.find('.wmo-expand-toggle');
            var $icon = $toggle.find('.dashicons');
            
            if ($wrapper.hasClass('expanded')) {
                // Collapse
                $wrapper.removeClass('expanded');
                $content.hide();
                $icon.removeClass('dashicons-arrow-up-alt2').addClass('dashicons-arrow-down-alt2');
            } else {
                // Expand
                $wrapper.addClass('expanded');
                $content.show();
                $icon.removeClass('dashicons-arrow-down-alt2').addClass('dashicons-arrow-up-alt2');
            }
        });
    }

    // Initialize icon system functionality
    function initIconSystemFunctionality() {
        console.log('WMO: Initializing icon system functionality');
        
        // Toggle icon settings
        $(document).on('change', '.enable-custom-icon', function() {
            console.log('WMO: Icon enable/disable clicked');
            var $settings = $(this).closest('.icon-section').find('.icon-settings');
            $settings.toggle($(this).is(':checked'));
        });
        
        // Switch between emoji and dashicon
        $(document).on('change', '.icon-type-selector', function() {
            console.log('WMO: Icon type selector changed');
            var type = $(this).val();
            var $section = $(this).closest('.icon-settings');
            
            if (type === 'emoji') {
                $section.find('.emoji-picker').show();
                $section.find('.dashicon-picker').hide();
            } else {
                $section.find('.emoji-picker').hide();
                $section.find('.dashicon-picker').show();
            }
        });
        
        // Search functionality
        $(document).on('keyup', '.icon-search-input', function() {
            var search = $(this).val().toLowerCase();
            var $picker = $(this).closest('.icon-settings').find('.emoji-picker:visible, .dashicon-picker:visible');
            
            if ($picker.hasClass('dashicon-picker')) {
                // Search dashicons
                $picker.find('.dashicon-option').each(function() {
                    var iconName = $(this).data('dashicon').toLowerCase();
                    var category = $(this).data('category').toLowerCase();
                    var matches = iconName.includes(search) || category.includes(search) || search.length === 0;
                    $(this).toggle(matches);
                });
            } else {
                // Search emojis
                $picker.find('.emoji-option').each(function() {
                    var category = $(this).data('category').toLowerCase();
                    var matches = category.includes(search) || search.length === 0;
                    $(this).toggle(matches);
                });
            }
        });
        
        // Select emoji - using direct event binding for better reliability
        $(document).off('click', '.emoji-option').on('click', '.emoji-option', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('WMO: Emoji option clicked:', $(this).data('emoji'));
            
            var emoji = $(this).data('emoji');
            var $section = $(this).closest('.icon-settings');
            var $iconSection = $(this).closest('.icon-section');
            var $menuWrapper = $iconSection.closest('.wmo-menu-item-wrapper');
            var menuSlug = $menuWrapper.data('original-slug'); // Use the actual menu slug
            
            // Fallback: if original-slug is not available, try the checkbox data attribute
            if (!menuSlug) {
                menuSlug = $iconSection.find('.enable-custom-icon').data('menu-slug');
            }
            
            console.log('WMO: Menu slug found:', menuSlug);
            
            // Highlight selected
            $section.find('.emoji-option').removeClass('selected').css('background', 'transparent');
            $(this).addClass('selected').css('background', '#0073aa');
            
            // Update preview
            $section.find('.preview-icon').html(emoji + ' ');
            $section.find('.selected-emoji').val(emoji);
            
            // Save via AJAX
            saveIconChoice(menuSlug, 'emoji', emoji);
            
            // Apply to actual menu immediately
            applyIconToMenu(menuSlug, 'emoji', emoji);
        });
        
        // Select dashicon - using direct event binding for better reliability
        $(document).off('click', '.dashicon-option').on('click', '.dashicon-option', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('WMO: Dashicon option clicked:', $(this).data('dashicon'));
            
            var dashicon = $(this).data('dashicon');
            var $section = $(this).closest('.icon-settings');
            var $iconSection = $(this).closest('.icon-section');
            var $menuWrapper = $iconSection.closest('.wmo-menu-item-wrapper');
            var menuSlug = $menuWrapper.data('original-slug'); // Use the actual menu slug
            
            // Fallback: if original-slug is not available, try the checkbox data attribute
            if (!menuSlug) {
                menuSlug = $iconSection.find('.enable-custom-icon').data('menu-slug');
            }
            
            console.log('WMO: Menu slug found:', menuSlug);
            
            // Highlight selected
            $section.find('.dashicon-option').removeClass('selected').css('background', 'transparent');
            $(this).addClass('selected').css('background', '#0073aa');
            
            // Update preview
            $section.find('.preview-icon').html('<span class="dashicons ' + dashicon + '"></span> ');
            $section.find('.selected-dashicon').val(dashicon);
            
            // Save via AJAX
            saveIconChoice(menuSlug, 'dashicon', dashicon);
            
            // Apply to actual menu immediately
            applyIconToMenu(menuSlug, 'dashicon', dashicon);
        });
        
        function saveIconChoice(menuSlug, type, value) {
            console.log('WMO: Saving icon choice:', menuSlug, type, value);
            
            if (!menuSlug) {
                console.error('WMO: No menu slug found for icon save');
                return;
            }
            
            if (typeof wmo_ajax === 'undefined') {
                console.error('WMO: wmo_ajax object not defined');
                return;
            }
            
            $.ajax({
                url: wmo_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'wmo_save_icon',
                    menu_id: menuSlug,
                    icon_type: type,
                    icon_value: value,
                    nonce: wmo_ajax.nonce
                },
                success: function(response) {
                    console.log('WMO: Icon save response:', response);
                    if (response.success) {
                        console.log('WMO: Icon saved successfully');
                    } else {
                        console.error('WMO: Error saving icon:', response.data);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('WMO: AJAX error saving icon:', status, error);
                    console.error('WMO: Response:', xhr.responseText);
                }
            });
        }
        
        function applyIconToMenu(menuSlug, type, value) {
            console.log('WMO: Applying icon to menu:', menuSlug, type, value);
            
            if (!menuSlug) {
                console.error('WMO: No menu slug found for icon application');
                return;
            }
            
            // Find the menu item in the WordPress admin menu
            var $menuItem = $('#adminmenu').find('[id*="' + menuSlug + '"]').first();
            
            if ($menuItem.length === 0) {
                // Try alternative selectors
                $menuItem = $('#adminmenu').find('a[href*="' + menuSlug + '"]').closest('li');
            }
            
            if ($menuItem.length === 0) {
                // Try more generic selectors
                $menuItem = $('#adminmenu li').filter(function() {
                    return $(this).text().toLowerCase().includes(menuSlug.replace(/-/g, ' ').toLowerCase());
                }).first();
            }
            
            if ($menuItem.length > 0) {
                var $iconWrapper = $menuItem.find('.wp-menu-image');
                
                if ($iconWrapper.length > 0) {
                    // Create the new icon HTML
                    var iconHtml = '';
                    if (type === 'emoji') {
                        iconHtml = '<span class="custom-menu-icon" style="font-size: 20px;">' + value + '</span>';
                    } else {
                        iconHtml = '<span class="dashicons ' + value + '" style="font-size: 20px;"></span>';
                    }
                    
                    // IMPORTANT: Clear ALL existing content first
                    $iconWrapper.empty();
                    
                    // Remove any existing dashicon classes from the wrapper
                    $iconWrapper.removeClass(function(index, className) {
                        return (className.match(/(^|\s)dashicons-\S+/g) || []).join(' ');
                    });
                    $iconWrapper.removeClass('dashicons');
                    
                    // Add custom icon class to help with CSS targeting
                    $iconWrapper.addClass('has-custom-icon');
                    
                    // Add the new icon
                    $iconWrapper.html(iconHtml);
                    
                    console.log('WMO: Icon applied to menu item:', $menuItem);
                } else {
                    console.log('WMO: Could not find icon wrapper in menu item');
                }
            } else {
                console.log('WMO: Could not find menu item for slug:', menuSlug);
                console.log('WMO: Available menu items:', $('#adminmenu li').map(function() {
                    return $(this).attr('id') || $(this).text().trim();
                }).get());
            }
        }
        
        // Apply saved icons on page load
        function applySavedIcons() {
            console.log('WMO: Applying saved icons on page load');
            
            // Get saved icons from localized script
            if (typeof wmo_saved_icons !== 'undefined' && wmo_saved_icons) {
                console.log('WMO: Found saved icons:', wmo_saved_icons);
                
                $.each(wmo_saved_icons, function(menuId, iconData) {
                    console.log('WMO: Applying saved icon for', menuId, ':', iconData);
                    applyIconToMenu(menuId, iconData.type, iconData.value);
                });
            } else {
                console.log('WMO: No saved icons found');
            }
        }
        
        // Apply saved icons after page loads
        setTimeout(function() {
            applySavedIcons();
        }, 1000);
        
        // Debug: Log available icon options on page load
        setTimeout(function() {
            console.log('WMO: Icon system initialized. Available emoji options:', $('.emoji-option').length);
            console.log('WMO: Available dashicon options:', $('.dashicon-option').length);
            console.log('WMO: Icon sections found:', $('.icon-section').length);
        }, 1000);
    }
    
    // Global function to toggle expand/collapse (called from PHP) - working version
    window.wmo_toggle_expand = function(button) {
        var $button = jQuery(button);
        var $wrapper = $button.siblings('.wmo-submenu-wrapper');
        
        if ($wrapper.hasClass('expanded')) {
            // Collapse
            $wrapper.removeClass('expanded').hide();
            $button.removeClass('expanded');
        } else {
            // Expand  
            $wrapper.addClass('expanded').show();
            $button.addClass('expanded');
        }
    };

})(jQuery);
