﻿<div class="wrap">
    <h1>WP Menu Organize Settings</h1>
    <div class="wmo-layout">
        <div class="wmo-main-content">
            <form method="post" action="options.php">
                <?php
                settings_fields('wmo_settings_group');
                do_settings_sections('wmo_settings_group');
                ?>

                
                <div class="wmo-section">
                    <h3>Menu Colors</h3>
                    <p class="description">
                        <em>⚡ Colors are automatically saved when you make changes - no need to click a save button!</em>
                    </p>
                    <div class="wmo-color-groups">
                        <!-- Column 1 -->
                        <div class="wmo-color-column">
                            <?php
                            // Process core WordPress items that may have submenus
                            global $menu, $submenu;
                            $core_items = ['dashboard', 'posts', 'media', 'pages', 'comments'];
                            $site_mgmt_items = ['appearance', 'plugins', 'users', 'tools', 'settings'];
                            
                            // Find actual menu entries for core items
                            $core_with_submenus = [];
                            $core_without_submenus = [];
                            $site_with_submenus = [];
                            $site_without_submenus = [];
                            
                            if (isset($menu) && is_array($menu)) {
                                foreach ($menu as $item) {
                                    $menu_slug = sanitize_title(strip_tags($item[0]));
                                    if (empty($menu_slug)) continue;
                                    
                                    $menu_title = preg_replace('/\d+/', '', strip_tags($item[0]));
                                    $menu_title = trim($menu_title);
                                    $menu_file = $item[2];
                                    
                                    // Check if this item has submenus
                                    $has_submenus = isset($submenu[$menu_file]) && !empty($submenu[$menu_file]);
                                    
                                    if (in_array($menu_slug, $core_items)) {
                                        if ($has_submenus) {
                                            $core_with_submenus[] = [
                                                'slug' => $menu_slug,
                                                'title' => $menu_title,
                                                'file' => $menu_file,
                                                'submenus' => $submenu[$menu_file]
                                            ];
                                        } else {
                                            $core_without_submenus[] = [
                                                'slug' => $menu_slug,
                                                'title' => $menu_title
                                            ];
                                        }
                                    } elseif (in_array($menu_slug, $site_mgmt_items)) {
                                        if ($has_submenus) {
                                            $site_with_submenus[] = [
                                                'slug' => $menu_slug,
                                                'title' => $menu_title,
                                                'file' => $menu_file,
                                                'submenus' => $submenu[$menu_file]
                                            ];
                                        } else {
                                            $site_without_submenus[] = [
                                                'slug' => $menu_slug,
                                                'title' => $menu_title
                                            ];
                                        }
                                    }
                                }
                            }
                            
                            // Display Core WordPress items with submenus
                            foreach ($core_with_submenus as $parent_item) {
                                echo '<div class="wmo-color-group wmo-parent-menu-group">';
                                echo '<h3><span class="dashicons dashicons-dashboard"></span> ' . esc_html($parent_item['title']) . ' & Submenus</h3>';
                                echo '<div class="wmo-color-items">';
                                
                                // Parent item
                                echo '<div class="wmo-parent-item">';
                                wmo_render_color_picker($menu_colors, $parent_item['slug'], $parent_item['title'] . ' (Parent)');
                                echo '</div>';
                                
                                // Child items
                                if (!empty($parent_item['submenus'])) {
                                    echo '<div class="wmo-submenu-items">';
                                    foreach ($parent_item['submenus'] as $subitem) {
                                        $submenu_slug = sanitize_title(strip_tags($subitem[0]));
                                        $submenu_title = strip_tags($subitem[0]);
                                        wmo_render_color_picker($menu_colors, $submenu_slug, $submenu_title, true);
                                    }
                                    echo '</div>';
                                }
                                
                                echo '</div>';
                                echo '</div>';
                            }
                            
                            // Display remaining core items without submenus (if any)
                            if (!empty($core_without_submenus)) {
                                echo '<div class="wmo-color-group">';
                                echo '<h3><span class="dashicons dashicons-dashboard"></span> Core WordPress (Simple)</h3>';
                                echo '<div class="wmo-color-items">';
                                foreach ($core_without_submenus as $item) {
                                    wmo_render_color_picker($menu_colors, $item['slug'], $item['title']);
                                }
                                echo '</div>';
                                echo '</div>';
                            }
                            
                            // Display Site Management items with submenus
                            foreach ($site_with_submenus as $parent_item) {
                                echo '<div class="wmo-color-group wmo-parent-menu-group">';
                                echo '<h3><span class="dashicons dashicons-admin-appearance"></span> ' . esc_html($parent_item['title']) . ' & Submenus</h3>';
                                echo '<div class="wmo-color-items">';
                                
                                // Parent item
                                echo '<div class="wmo-parent-item">';
                                wmo_render_color_picker($menu_colors, $parent_item['slug'], $parent_item['title'] . ' (Parent)');
                                echo '</div>';
                                
                                // Child items
                                if (!empty($parent_item['submenus'])) {
                                    echo '<div class="wmo-submenu-items">';
                                    foreach ($parent_item['submenus'] as $subitem) {
                                        $submenu_slug = sanitize_title(strip_tags($subitem[0]));
                                        $submenu_title = strip_tags($subitem[0]);
                                        wmo_render_color_picker($menu_colors, $submenu_slug, $submenu_title, true);
                                    }
                                    echo '</div>';
                                }
                                
                                echo '</div>';
                                echo '</div>';
                            }
                            
                            // Display remaining site management items without submenus (if any)
                            if (!empty($site_without_submenus)) {
                                echo '<div class="wmo-color-group">';
                                echo '<h3><span class="dashicons dashicons-admin-appearance"></span> Site Management (Simple)</h3>';
                                echo '<div class="wmo-color-items">';
                                foreach ($site_without_submenus as $item) {
                                    wmo_render_color_picker($menu_colors, $item['slug'], $item['title']);
                                }
                                echo '</div>';
                                echo '</div>';
                            }
                            ?>
                        </div>
                        
                        <!-- Column 2 -->
                        <div class="wmo-color-column">
                            <?php
                            // Collect plugin menu items and other items with submenus
                            $plugin_items = [];
                            $other_items_with_submenus = [];
                            
                            if (isset($menu) && is_array($menu)) {
                                foreach ($menu as $item) {
                                    $menu_slug = sanitize_title(strip_tags($item[0]));
                                    if (empty($menu_slug)) continue;
                                    
                                    // Skip core WordPress and site management items (already handled in column 1)
                                    if (in_array($menu_slug, array_merge($core_items, $site_mgmt_items))) continue;

                                    $menu_title = preg_replace('/\d+/', '', strip_tags($item[0]));
                                    $menu_title = trim($menu_title);
                                    $menu_file = $item[2];
                                    
                                    // Check if this item has submenus
                                    $has_submenus = isset($submenu[$menu_file]) && !empty($submenu[$menu_file]);
                                    
                                    if ($has_submenus) {
                                        $other_items_with_submenus[] = [
                                            'slug' => $menu_slug,
                                            'title' => $menu_title,
                                            'file' => $menu_file,
                                            'submenus' => $submenu[$menu_file]
                                        ];
                                    } else {
                                        $plugin_items[] = [
                                            'slug' => $menu_slug,
                                            'title' => $menu_title
                                        ];
                                    }
                                }
                            }
                            
                            // Display plugin items without submenus
                            if (!empty($plugin_items)) {
                                echo '<div class="wmo-color-group">';
                                echo '<h3><span class="dashicons dashicons-admin-plugins"></span> Plugin Menu Items</h3>';
                                echo '<div class="wmo-color-items">';
                                foreach ($plugin_items as $item) {
                                    wmo_render_color_picker($menu_colors, $item['slug'], $item['title']);
                                }
                                echo '</div>';
                                echo '</div>';
                            }
                            
                            // Display other items with submenus in separate sections
                            foreach ($other_items_with_submenus as $parent_item) {
                                echo '<div class="wmo-color-group wmo-parent-menu-group">';
                                echo '<h3><span class="dashicons dashicons-menu-alt3"></span> ' . esc_html($parent_item['title']) . ' & Submenus</h3>';
                                echo '<div class="wmo-color-items">';
                                
                                // Parent item
                                echo '<div class="wmo-parent-item">';
                                wmo_render_color_picker($menu_colors, $parent_item['slug'], $parent_item['title'] . ' (Parent)');
                                echo '</div>';
                                
                                // Child items
                                if (!empty($parent_item['submenus'])) {
                                    echo '<div class="wmo-submenu-items">';
                                    foreach ($parent_item['submenus'] as $subitem) {
                                        $submenu_slug = sanitize_title(strip_tags($subitem[0]));
                                        $submenu_title = strip_tags($subitem[0]);
                                        wmo_render_color_picker($menu_colors, $submenu_slug, $submenu_title, true);
                                    }
                                    echo '</div>';
                                }
                                
                                echo '</div>';
                                echo '</div>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    .wmo-layout {
        display: flex;
        gap: 20px;
    }

    .wmo-main-content {
        flex: 1;
    }

    .wmo-sidebar {
        width: 250px;
    }

    .wmo-color-groups {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 25px;
        align-items: start;
    }

    .wmo-color-column {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .wmo-color-group {
        background: #fff;
        padding: 18px;
        border: 1px solid #ddd;
        border-radius: 6px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        transition: box-shadow 0.2s ease;
    }

    .wmo-color-group:hover {
        box-shadow: 0 4px 8px rgba(0,0,0,0.15);
    }

    .wmo-color-group h3 {
        margin-top: 0;
        margin-bottom: 18px;
        color: #23282d;
        font-size: 15px;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 8px;
        padding-bottom: 10px;
        border-bottom: 2px solid #0073aa;
    }

    .wmo-color-group h3 .dashicons {
        color: #0073aa;
        font-size: 18px;
    }

    .wmo-color-items {
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    /* Parent menu group styling */
    .wmo-parent-menu-group {
        border-left: 4px solid #0073aa;
    }

    .wmo-parent-menu-group h3 {
        border-bottom-color: #0073aa;
        background: linear-gradient(90deg, rgba(0,115,170,0.05) 0%, transparent 100%);
        margin-left: -18px;
        margin-right: -18px;
        margin-top: -18px;
        padding: 12px 18px;
        border-radius: 6px 6px 0 0;
    }

    /* Parent item styling */
    .wmo-parent-item {
        background: rgba(0,115,170,0.05);
        padding: 10px;
        border-radius: 4px;
        border-left: 3px solid #0073aa;
        margin-bottom: 12px;
    }

    .wmo-parent-item .wmo-color-picker-wrapper {
        margin-bottom: 0;
    }

    .wmo-parent-item .wmo-color-picker-wrapper label {
        font-weight: 600;
        color: #0073aa;
    }

    /* Submenu items styling */
    .wmo-submenu-items {
        background: #f9f9f9;
        padding: 12px;
        border-radius: 4px;
        border: 1px solid #e5e5e5;
        position: relative;
    }

    .wmo-submenu-items::before {
        content: "Child Menu Items";
        display: block;
        font-size: 11px;
        font-weight: 600;
        color: #666;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 8px;
        padding-bottom: 4px;
        border-bottom: 1px solid #ddd;
    }

    .wmo-submenu-items .wmo-color-picker-wrapper {
        margin-bottom: 8px;
        padding-left: 12px;
        position: relative;
    }

    .wmo-submenu-items .wmo-color-picker-wrapper::before {
        content: "â””";
        position: absolute;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
        color: #999;
        font-family: monospace;
        font-weight: bold;
    }

    .wmo-submenu-items .wmo-color-picker-wrapper:last-child {
        margin-bottom: 0;
    }

    .wmo-submenu-items .wmo-color-picker-wrapper label {
        font-size: 13px;
        color: #555;
    }

    .wmo-color-picker-wrapper {
        display: flex;
        align-items: center;
        margin-bottom: 12px;
        padding: 8px;
        border-radius: 4px;
        transition: background-color 0.2s ease;
    }

    .wmo-color-picker-wrapper:hover {
        background-color: rgba(0,0,0,0.02);
    }

    .wmo-color-picker-wrapper label {
        flex: 1;
        font-weight: 500;
        margin-right: 12px;
        color: #23282d;
    }

    .wmo-color-picker-wrapper input[type="text"] {
        width: 100px;
    }
    
    /* Override default color group styling for new menu item wrapper */
    .wmo-color-group .wmo-menu-item-wrapper {
        background: #f9f9f9;
        border: 1px solid #e0e0e0;
        margin-bottom: 15px;
        padding: 12px;
    }
    
    .wmo-color-group .wmo-menu-item-wrapper:hover {
        background: #f5f5f5;
        box-shadow: 0 1px 4px rgba(0,0,0,0.1);
    }

    /* Responsive design for smaller screens */
    @media (max-width: 1200px) {
        .wmo-color-groups {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 768px) {
        .wmo-color-group {
            padding: 15px;
        }
        
        .wmo-color-picker-wrapper {
            flex-direction: column;
            align-items: flex-start;
            gap: 8px;
        }
        
        .wmo-color-picker-wrapper label {
            margin-right: 0;
        }
    }
</style>
