﻿<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="wrap">
    <h1>Menu Templates</h1>
    <div class="wmo-section wmo-templates-section">
        <h3><span class="dashicons dashicons-art"></span> Menu Templates</h3>
        <div class="wmo-templates-gallery" id="wmo-templates-gallery">
            <div class="wmo-templates-loading">
                <span class="dashicons dashicons-update-alt wmo-spin"></span>
                Loading templates...
            </div>
        </div>
    </div>
</div>
