﻿(function($) {
    'use strict';

    // Debounce function for performance optimization
    function debounce(func, wait, immediate) {
        var timeout;
        return function() {
            var context = this, args = arguments;
            var later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            var callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    }

    // Auto-save timeouts storage
    var autoSaveTimeouts = {};

    // Initialize color picker functionality
    function initColorPickers() {
        console.log('WMO: Initializing WordPress color pickers');
        
        if (!$.fn.wpColorPicker) {
            console.error('WMO: WordPress Color Picker not available');
            return;
        }

        // Initialize main color fields
        $('.wmo-color-field').wpColorPicker({
            defaultColor: '#23282d',
            palettes: [
                '#23282d', '#0073aa', '#00a0d2', '#0085ba',
                '#006799', '#00b9eb', '#91c5f2', '#ddd'
            ],
            change: debounce(function(event, ui) {
                var $input = $(this);
                var slug = $input.data('menu-slug');
                var color = ui.color.toString();
                var isSubmenu = $input.data('is-submenu') === true;

                console.log('WMO: Color changed for', slug, 'to', color);

                // Update input value
                $input.val(color);
                
                // Trigger custom event
                $(document).trigger('wmoColorChanged', [slug, color, isSubmenu]);
                
                // Auto-save color
                if (slug) {
                    wmoAutoSaveColor(slug, color, $input);
                }
                
                // Auto-close picker after delay
                setTimeout(function() {
                    $input.wpColorPicker('close');
                }, 300);
            }, 300),
            clear: function(event, ui) {
                var $input = $(this);
                var slug = $input.data('menu-slug');
                
                console.log('WMO: Color cleared for', slug);
                $input.val('');
                
                if (slug) {
                    wmoAutoSaveColor(slug, '', $input);
                }
                
                setTimeout(function() {
                    $input.wpColorPicker('close');
                }, 300);
            }
        });

        // Initialize badge color pickers
        $('.wmo-badge-color-picker, .wmo-badge-bg-picker').wpColorPicker({
            change: debounce(function(event, ui) {
                var $input = $(this);
                var slug = $input.closest('.wmo-badge-wrapper').data('menu-slug');
                var color = ui.color.toString();
                
                console.log('WMO: Badge color changed for', slug, 'to', color);
                
                // Update badge preview
                wmoUpdateBadgePreview(slug);
                
                // Auto-save badge
                if (slug) {
                    wmoAutoSaveBadge(slug);
                }
                
                setTimeout(function() {
                    $input.wpColorPicker('close');
                }, 300);
            }, 300)
        });
    }

    // Auto-save color function
    function wmoAutoSaveColor(slug, color, $input) {
        // Clear existing timeout
        if (autoSaveTimeouts[slug]) {
            clearTimeout(autoSaveTimeouts[slug]);
        }

        // Show saving indicator
        wmoShowSavingIndicator($input, 'Saving...', 'info');

        // Set new timeout
        autoSaveTimeouts[slug] = setTimeout(function() {
            $.ajax({
                url: wmo_ajax.ajax_url,
                method: 'POST',
                data: {
                    action: 'wmo_save_color',
                    id: slug,
                    color: color,
                    nonce: wmo_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        wmoShowSavingIndicator($input, 'Saved!', 'success');
                        console.log('WMO: Color saved successfully for', slug);
                    } else {
                        wmoShowSavingIndicator($input, 'Error saving', 'error');
                        console.error('WMO: Color save failed:', response.data);
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    wmoShowSavingIndicator($input, 'Network error', 'error');
                    console.error('WMO: Color save AJAX error:', textStatus, errorThrown);
                }
            });
        }, 500);
    }

    // Show saving indicator
    function wmoShowSavingIndicator($input, message, type = 'info') {
        var $indicator = $input.siblings('.wmo-saving-indicator');
        if ($indicator.length === 0) {
            $indicator = $('<div class="wmo-saving-indicator"></div>');
            $input.parent().append($indicator);
        }
        
        $indicator.text(message).removeClass('success error info').addClass(type);
        
        if (type === 'success') {
            setTimeout(function() {
                $indicator.fadeOut();
            }, 2000);
        }
    }

    // Badge functionality
    function initBadgeFunctionality() {
        // Badge enable/disable
        $(document).on('change', '.wmo-badge-enable', function() {
            var $wrapper = $(this).closest('.wmo-badge-wrapper');
            var slug = $wrapper.data('menu-slug');
            var enabled = $(this).is(':checked');
            
            $wrapper.find('.wmo-badge-controls').toggle(enabled);
            
            if (enabled) {
                wmoUpdateBadgePreview(slug);
                wmoAutoSaveBadge(slug);
            } else {
                wmoRemoveBadgeFromMenu(slug);
                wmoAutoSaveBadge(slug);
            }
        });

        // Badge text input
        $(document).on('input', '.wmo-badge-text', function() {
            var $wrapper = $(this).closest('.wmo-badge-wrapper');
            var slug = $wrapper.data('menu-slug');
            
            clearTimeout(window.wmoBadgeTextTimeout);
            window.wmoBadgeTextTimeout = setTimeout(function() {
                wmoUpdateBadgePreview(slug);
                wmoAutoSaveBadge(slug);
            }, 300);
        });
    }

    // Update badge preview
    function wmoUpdateBadgePreview(slug) {
        var $wrapper = $('.wmo-badge-wrapper').filter(function() {
            return $(this).data('menu-slug') === slug;
        });
        
        if ($wrapper.length === 0) return;
        
        var text = $wrapper.find('.wmo-badge-text').val();
        var color = $wrapper.find('.wmo-badge-color-picker').val();
        var background = $wrapper.find('.wmo-badge-bg-picker').val();
        var enabled = $wrapper.find('.wmo-badge-enable').is(':checked');
        
        var $preview = $wrapper.find('.wmo-badge-preview');
        if ($preview.length === 0) {
            $preview = $('<span class="wmo-badge-preview"></span>');
            $wrapper.find('.wmo-badge-controls').append($preview);
        }
        
        if (enabled && text) {
            $preview.text(text).css({
                'color': color || '#ffffff',
                'background-color': background || '#0073aa'
            }).show();
        } else {
            $preview.hide();
        }
    }

    // Auto-save badge
    function wmoAutoSaveBadge(slug) {
        var $wrapper = $('.wmo-badge-wrapper').filter(function() {
            return $(this).data('menu-slug') === slug;
        });
        
        if ($wrapper.length === 0) return;
        
        var enabled = $wrapper.find('.wmo-badge-enable').is(':checked');
        var text = $wrapper.find('.wmo-badge-text').val();
        var color = $wrapper.find('.wmo-badge-color-picker').val();
        var background = $wrapper.find('.wmo-badge-bg-picker').val();
        
        $.ajax({
            url: wmo_ajax.ajax_url,
            method: 'POST',
            data: {
                action: 'wmo_save_badge',
                slug: slug,
                enabled: enabled,
                text: text,
                color: color,
                background: background,
                nonce: wmo_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    console.log('WMO: Badge saved successfully for', slug);
                } else {
                    console.error('WMO: Badge save failed:', response.data);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('WMO: Badge save AJAX error:', textStatus, errorThrown);
            }
        });
    }

    // Remove badge from menu
    function wmoRemoveBadgeFromMenu(slug) {
        var selectors = [
            "#menu-" + slug + " > a .wp-menu-name .wmo-menu-badge",
            "#toplevel_page_" + slug + " > a .wp-menu-name .wmo-menu-badge"
        ];
        
        selectors.forEach(function(selector) {
            $(selector).remove();
        });
    }

    // Theme toggle functionality
    function initThemeToggle() {
        var $themeToggle = $('#wmo-dark-mode-toggle');
        if ($themeToggle.length === 0) return;
        
        $themeToggle.on('change', function() {
            var isDarkMode = $(this).is(':checked');
            
            // Apply theme immediately
            if (isDarkMode) {
                $('body').addClass('wmo-dark-theme');
            } else {
                $('body').removeClass('wmo-dark-theme');
            }
            
            // Auto-save theme
            wmoAutoSaveTheme(isDarkMode);
        });
    }

    // Auto-save theme
    function wmoAutoSaveTheme(isDarkMode) {
        $.ajax({
            url: wmo_ajax.ajax_url,
            method: 'POST',
            data: {
                action: 'wmo_save_theme',
                dark_mode: isDarkMode,
                nonce: wmo_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    console.log('WMO: Theme saved successfully');
                } else {
                    console.error('WMO: Theme save failed:', response.data);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('WMO: Theme save AJAX error:', textStatus, errorThrown);
            }
        });
    }

    // Initialize everything when document is ready
    $(document).ready(function() {
        console.log('WMO: Color picker script loaded');
        
        // Initialize color pickers
        initColorPickers();
        
        // Initialize badge functionality
        initBadgeFunctionality();
        
        // Initialize theme toggle
        initThemeToggle();
        
        // Handle color swatch clicks (if any)
        $(document).on('click', '.color-swatch', function(e) {
            e.preventDefault();
            var $swatch = $(this);
            var $input = $swatch.siblings('.wmo-color-field');
            if ($input.length) {
                $input.wpColorPicker('open');
            }
        });
    });

})(jQuery);
