<?php
// Debug file to understand WordPress admin menu structure
// Add this to wp-admin/admin.php temporarily to see the actual menu structure

if (!defined('ABSPATH')) {
    exit;
}

// Hook into admin head to output debug info
add_action('admin_head', 'wmo_debug_menu_structure');

function wmo_debug_menu_structure() {
    global $menu, $submenu;
    
    echo '<script type="text/javascript">';
    echo 'console.log("=== WMO MENU STRUCTURE DEBUG ===");';
    echo 'console.log("Global menu structure:");';
    
    if (!empty($menu)) {
        foreach ($menu as $key => $item) {
            $menu_title = strip_tags($item[0]);
            $menu_file = $item[2];
            $menu_slug = sanitize_title($menu_title);
            
            echo "console.log('Menu item: {$menu_title} -> File: {$menu_file} -> Slug: {$menu_slug}');";
            
            // Check if this menu has submenus
            if (isset($submenu[$menu_file]) && !empty($submenu[$menu_file])) {
                echo "console.log('  Has submenus:');";
                foreach ($submenu[$menu_file] as $subitem) {
                    $submenu_title = strip_tags($subitem[0]);
                    $submenu_slug = sanitize_title($submenu_title);
                    echo "console.log('    - {$submenu_title} -> Slug: {$submenu_slug}');";
                }
            }
        }
    }
    
    echo 'console.log("=== END MENU STRUCTURE DEBUG ===");';
    echo '</script>';
}
