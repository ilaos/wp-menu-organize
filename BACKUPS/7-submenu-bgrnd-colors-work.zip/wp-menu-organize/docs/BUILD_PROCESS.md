# WP Menu Organize - Build Process Documentation

## Overview
The plugin uses a modern Node.js-based build process to optimize assets for production.

## Prerequisites
- Node.js 14.0.0 or higher
- npm 6.0.0 or higher

## Installation

### First Time Setup
```bash
# Navigate to plugin directory
cd wp-content/plugins/wp-menu-organize

# Install dependencies
npm install
```

## Available Commands

### Build for Production
```bash
npm run build
# or
./build.sh
```
Minifies all CSS and JavaScript files into the `assets/dist/` directory.

### Development Mode
```bash
npm run watch
# or
npm run dev
```
Automatically rebuilds files when changes are detected in `assets/src/`.

### Clean Build
```bash
npm run clean
```
Removes all files from `assets/dist/` directory.

### Code Quality
```bash
# Check for JavaScript issues
npm run lint

# Fix auto-fixable issues
npm run lint:fix
```

## Project Structure
```
assets/
├── src/           # Development files (unminified)
│   ├── css/
│   │   └── admin.css
│   └── js/
│       ├── admin.js
│       ├── color-picker.js
│       ├── icon-applier.js
│       ├── icon-picker.js
│       └── templates.js
└── dist/          # Production files (minified)
    ├── css/
    │   └── admin.min.css
    └── js/
        ├── admin.min.js
        ├── color-picker.min.js
        └── [other minified files]
```

## How It Works

### Automatic File Selection
The plugin's `wmo_get_asset_url()` function automatically:
- Uses minified files (`dist/`) in production
- Uses source files (`src/`) when `WP_DEBUG` or `SCRIPT_DEBUG` is enabled
- Adds cache busting via file modification timestamps

### WordPress Configuration

#### For Development
Add to `wp-config.php`:
```php
define('WP_DEBUG', true);
define('SCRIPT_DEBUG', true);
```

#### For Production
Ensure these are set to `false` or removed:
```php
define('WP_DEBUG', false);
define('SCRIPT_DEBUG', false);
```

## Build Tools

### CSS Minification
- **Tool**: clean-css-cli
- **Compression**: Removes whitespace, combines rules, optimizes selectors

### JavaScript Minification
- **Tool**: Terser
- **Features**: 
  - Compression (`-c`): Removes dead code, optimizes conditionals
  - Mangle (`-m`): Shortens variable names
  - ES6+ support

### Code Quality
- **Tool**: ESLint
- **Config**: `.eslintrc.json`
- **Rules**: WordPress coding standards compatible

## Optimization Results
Typical compression rates:
- CSS: 40-50% file size reduction
- JavaScript: 50-60% file size reduction
- Overall: ~50% bandwidth savings

## Continuous Integration
For CI/CD pipelines:
```bash
# Install, build, and verify
npm ci
npm run build
npm run lint
```

## Troubleshooting

### Node/npm not found
Install Node.js from [nodejs.org](https://nodejs.org/)

### Permission errors
```bash
# Fix npm permissions
npm cache clean --force
```

### Build failures
```bash
# Clean and rebuild
npm run clean
npm install
npm run build
```

## Contributing
1. Always work in `assets/src/` files
2. Run `npm run lint` before committing
3. Test with both `SCRIPT_DEBUG` true and false
4. Commit both source and minified files

## Performance Impact
- First load: 50% faster with minified files
- Cached loads: Minimal difference
- Development: No minification overhead

## Future Enhancements
- [ ] Source maps for debugging
- [ ] Autoprefixer for CSS
- [ ] Bundle splitting for large files
- [ ] Image optimization pipeline
- [ ] TypeScript support