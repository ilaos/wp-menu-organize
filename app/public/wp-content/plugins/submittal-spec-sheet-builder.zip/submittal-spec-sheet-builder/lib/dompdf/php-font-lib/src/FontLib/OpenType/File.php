<?php
/**
 * @package php-font-lib
 * @link    https://github.com/dompdf/php-font-lib
 * @license http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License
 */

namespace FontLib\OpenType;

/**
 * Open Type font, the same as a TrueType one.
 *
 * @package php-font-lib
 */
class File extends \FontLib\TrueType\File {
  //
}
